<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add_keys') {
        $tierId = (int)$_POST['tier_id'];
        $productId = (int)$_POST['product_id'];
        $keysText = trim($_POST['keys'] ?? '');
        $keys = array_filter(array_map('trim', explode("\n", $keysText)));

        if ($tierId && $productId && !empty($keys)) {
            $stmt = $pdo->prepare("INSERT INTO license_keys (tier_id, product_id, key_value, status, created_at) VALUES (?, ?, ?, 'available', NOW())");
            $count = 0;
            foreach ($keys as $key) {
                $stmt->execute([$tierId, $productId, $key]);
                $count++;
            }
            $message = "$count key(s) added successfully";
            $messageType = 'success';
        }
    }

    if ($action === 'delete_key') {
        $keyId = (int)$_POST['key_id'];
        $pdo->prepare("DELETE FROM license_keys WHERE id = ? AND status = 'available'")->execute([$keyId]);
        $message = 'Key deleted';
        $messageType = 'success';
    }

    header("Location: /admin/keys.php" . ($message ? "?msg=" . urlencode($message) . "&type=$messageType" : ""));
    exit;
}

if (isset($_GET['msg'])) {
    $message = $_GET['msg'];
    $messageType = $_GET['type'] ?? 'success';
}

$products = $pdo->query("SELECT * FROM products ORDER BY id DESC")->fetchAll();
foreach ($products as &$p) {
    $stmt = $pdo->prepare("SELECT * FROM pricing_tiers WHERE product_id = ? ORDER BY sort_order, price");
    $stmt->execute([$p['id']]);
    $p['tiers'] = $stmt->fetchAll();

    foreach ($p['tiers'] as &$t) {
        $stmt2 = $pdo->prepare("SELECT COUNT(*) as total, SUM(CASE WHEN status='available' THEN 1 ELSE 0 END) as available FROM license_keys WHERE tier_id = ?");
        $stmt2->execute([$t['id']]);
        $stock = $stmt2->fetch();
        $t['total_keys'] = (int)($stock['total'] ?? 0);
        $t['available_keys'] = (int)($stock['available'] ?? 0);
    }
}
unset($p, $t);

$purchases = $pdo->query("
    SELECT p.*, pr.name as product_name, pt.label as tier_label, u.username as user_email
    FROM purchases p
    LEFT JOIN products pr ON p.product_id = pr.id
    LEFT JOIN pricing_tiers pt ON p.tier_id = pt.id
    LEFT JOIN users u ON p.user_id = u.id
    ORDER BY p.created_at DESC
    LIMIT 100
")->fetchAll();

$activeTab = $_GET['tab'] ?? 'add';
$viewProduct = isset($_GET['view_product']) ? (int)$_GET['view_product'] : null;
$viewTier = isset($_GET['view_tier']) ? (int)$_GET['view_tier'] : null;

$tierKeys = [];
if ($viewTier) {
    $stmt = $pdo->prepare("SELECT * FROM license_keys WHERE tier_id = ? ORDER BY status, created_at DESC");
    $stmt->execute([$viewTier]);
    $tierKeys = $stmt->fetchAll();
}

$pendingPayments = (int)$pdo->query("SELECT COUNT(*) FROM payment_sessions WHERE status = 'pending'")->fetchColumn();

if (file_exists(__DIR__ . '/../includes/admin_header.php')) {
    require_once __DIR__ . '/../includes/admin_header.php';
} else {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>License Keys - Admin - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="admin-sidebar-header">
            <h2><?= SITE_NAME ?></h2>
            <span class="text-muted text-xs">ADMIN</span>
        </div>
        <nav class="admin-nav">
            <a href="/admin/index.php" class="admin-nav-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                Dashboard
            </a>
            <a href="/admin/products.php" class="admin-nav-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
                Products
            </a>
            <a href="/admin/keys.php" class="admin-nav-item active">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>
                License Keys
            </a>
            <a href="/admin/users.php" class="admin-nav-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                Users
            </a>
            <a href="/admin/payments.php" class="admin-nav-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                Payments
                <?php if ($pendingPayments > 0): ?><span class="admin-badge-count"><?= $pendingPayments ?></span><?php endif; ?>
            </a>
            <a href="/admin/index.php?logout=1" class="admin-nav-item admin-nav-logout">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                Logout
            </a>
        </nav>
    </aside>
    <main class="admin-main">
<?php } ?>

<div class="admin-page-header">
    <h1 data-testid="text-admin-keys-title">License Keys</h1>
    <div class="tab-buttons">
        <a href="/admin/keys.php?tab=add" class="btn-sm <?= $activeTab === 'add' ? 'btn-primary' : 'btn-outline' ?>" data-testid="tab-add-keys">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            Add Keys
        </a>
        <a href="/admin/keys.php?tab=sold" class="btn-sm <?= $activeTab === 'sold' ? 'btn-primary' : 'btn-outline' ?>" data-testid="tab-sold-keys">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>
            Sold Keys
            <span class="badge badge-secondary badge-sm"><?= count($purchases) ?></span>
        </a>
    </div>
</div>

<?php if ($message): ?>
    <div class="alert alert-<?= $messageType ?>"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<?php if ($activeTab === 'add'): ?>

<div class="card" style="margin-bottom: 16px;">
    <div class="card-body">
        <h2 class="section-label">ADD LICENSE KEYS TO STOCK</h2>

        <form method="POST" id="addKeysForm">
            <input type="hidden" name="action" value="add_keys">

            <div class="form-group">
                <label class="form-label">SELECT PRODUCT</label>
                <div class="product-select-grid">
                    <?php foreach ($products as $p): ?>
                        <label class="product-select-btn <?= ($viewProduct === $p['id']) ? 'active' : '' ?>">
                            <input type="radio" name="product_id_select" value="<?= $p['id'] ?>" onchange="selectProduct(<?= $p['id'] ?>)" <?= ($viewProduct === $p['id']) ? 'checked' : '' ?>>
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
                            <?= htmlspecialchars($p['name']) ?>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>

            <?php if ($viewProduct):
                $selectedProduct = null;
                foreach ($products as $p) {
                    if ($p['id'] === $viewProduct) { $selectedProduct = $p; break; }
                }
                if ($selectedProduct && !empty($selectedProduct['tiers'])):
            ?>
                <div class="form-group">
                    <label class="form-label">SELECT TIER</label>
                    <div class="tier-select-group">
                        <?php foreach ($selectedProduct['tiers'] as $t): ?>
                            <label class="tier-select-btn <?= ($viewTier === $t['id']) ? 'active' : '' ?>">
                                <input type="radio" name="tier_id_select" value="<?= $t['id'] ?>" onchange="selectTier(<?= $viewProduct ?>, <?= $t['id'] ?>)" <?= ($viewTier === $t['id']) ? 'checked' : '' ?>>
                                <?= htmlspecialchars($t['label']) ?> - <?= formatINR($t['price']) ?>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <?php if ($viewTier): ?>
                    <input type="hidden" name="tier_id" value="<?= $viewTier ?>">
                    <input type="hidden" name="product_id" value="<?= $viewProduct ?>">
                    <div class="form-group">
                        <label class="form-label">PASTE LICENSE KEYS (ONE PER LINE)</label>
                        <textarea name="keys" rows="6" class="input-field font-mono text-xs" placeholder="XXXX-XXXX-XXXX-XXXX&#10;YYYY-YYYY-YYYY-YYYY&#10;ZZZZ-ZZZZ-ZZZZ-ZZZZ" data-testid="textarea-keys" id="keysTextarea"></textarea>
                    </div>
                    <div class="form-actions-between">
                        <p class="text-muted text-xs" id="keyCount">0 keys ready to add</p>
                        <button type="submit" class="btn-primary btn-sm" data-testid="button-add-keys">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                            Add Keys
                        </button>
                    </div>
                <?php endif; ?>
            <?php endif; endif; ?>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <h2 class="section-label">KEY STOCK BY PRODUCT</h2>
        <?php foreach ($products as $p):
            $totalAvailable = 0;
            $totalKeys = 0;
            foreach ($p['tiers'] as $t) {
                $totalAvailable += $t['available_keys'];
                $totalKeys += $t['total_keys'];
            }
        ?>
            <div class="stock-product-section" data-testid="stock-product-<?= $p['id'] ?>">
                <button class="stock-product-header" onclick="toggleStockProduct(<?= $p['id'] ?>)" data-testid="button-toggle-stock-<?= $p['id'] ?>">
                    <div class="stock-product-name">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
                        <span><?= htmlspecialchars($p['name']) ?></span>
                    </div>
                    <div class="stock-product-stats">
                        <span class="badge badge-<?= $totalAvailable > 0 ? 'success' : 'danger' ?> badge-sm">
                            <?= $totalAvailable ?> available / <?= $totalKeys ?> total
                        </span>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="chevron-icon"><polyline points="6 9 12 15 18 9"/></svg>
                    </div>
                </button>
                <div id="stockProduct<?= $p['id'] ?>" class="stock-product-body" style="display:none;">
                    <?php foreach ($p['tiers'] as $t): ?>
                        <div class="stock-tier-row">
                            <div class="stock-tier-info">
                                <span class="text-xs font-medium"><?= htmlspecialchars($t['label']) ?> - <?= formatINR($t['price']) ?></span>
                                <span class="badge badge-<?= $t['available_keys'] > 0 ? 'outline' : 'danger' ?> badge-xs"><?= $t['available_keys'] ?> available</span>
                            </div>
                            <a href="/admin/keys.php?tab=add&view_product=<?= $p['id'] ?>&view_tier=<?= $t['id'] ?>#viewkeys" class="btn-sm btn-ghost" data-testid="button-view-keys-<?= $t['id'] ?>">View Keys</a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php if ($viewTier && !empty($tierKeys)): ?>
<div class="card" style="margin-top: 16px;" id="viewkeys">
    <div class="card-body">
        <h2 class="section-label">KEYS IN TIER</h2>
        <?php foreach ($tierKeys as $k): ?>
            <div class="key-stock-row">
                <div class="key-stock-info">
                    <span class="badge badge-<?= $k['status'] === 'available' ? 'outline' : 'secondary' ?> badge-xs"><?= $k['status'] ?></span>
                    <code class="key-value"><?= htmlspecialchars($k['key_value']) ?></code>
                </div>
                <?php if ($k['status'] === 'available'): ?>
                    <form method="POST" style="display:inline" onsubmit="return confirm('Delete this key?')">
                        <input type="hidden" name="action" value="delete_key">
                        <input type="hidden" name="key_id" value="<?= $k['id'] ?>">
                        <button type="submit" class="btn-icon btn-danger btn-xs" data-testid="button-delete-key-<?= $k['id'] ?>">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<?php else: ?>

<?php if (empty($purchases)): ?>
    <div class="card text-center" style="padding: 40px;">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin: 0 auto 8px; opacity: 0.5"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>
        <p class="text-muted">No license keys sold yet.</p>
    </div>
<?php else: ?>
    <div class="keys-list">
        <?php foreach ($purchases as $p): ?>
            <div class="card key-sold-card" data-testid="card-admin-key-<?= $p['id'] ?>">
                <div class="card-body">
                    <div class="key-sold-row">
                        <div class="key-sold-info">
                            <div class="key-sold-icon">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>
                            </div>
                            <div>
                                <div class="key-sold-meta">
                                    <span class="font-semibold text-sm" data-testid="text-key-product-<?= $p['id'] ?>"><?= htmlspecialchars($p['product_name'] ?? 'Product #' . $p['product_id']) ?></span>
                                    <span class="badge badge-secondary badge-xs"><?= htmlspecialchars($p['tier_label'] ?? '') ?></span>
                                </div>
                                <p class="text-muted text-xs">
                                    User: <?= htmlspecialchars($p['user_email'] ?? $p['user_id']) ?>
                                    | <?= formatINR($p['amount']) ?>
                                    | <?= date('M j, Y', strtotime($p['created_at'])) ?>
                                </p>
                            </div>
                        </div>
                        <div class="key-sold-value">
                            <code class="key-value" data-testid="text-license-key-<?= $p['id'] ?>"><?= htmlspecialchars($p['license_key'] ?? '') ?></code>
                            <button class="btn-icon btn-ghost" onclick="copyToClipboard('<?= htmlspecialchars($p['license_key'] ?? '', ENT_QUOTES) ?>')" data-testid="button-copy-key-<?= $p['id'] ?>">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php endif; ?>

<script>
function selectProduct(productId) {
    window.location.href = '/admin/keys.php?tab=add&view_product=' + productId;
}
function selectTier(productId, tierId) {
    window.location.href = '/admin/keys.php?tab=add&view_product=' + productId + '&view_tier=' + tierId;
}
function toggleStockProduct(id) {
    var el = document.getElementById('stockProduct' + id);
    el.style.display = el.style.display === 'none' ? 'block' : 'none';
}
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(function() {
        showToast('Copied to clipboard');
    });
}
var keysTextarea = document.getElementById('keysTextarea');
var keyCountEl = document.getElementById('keyCount');
if (keysTextarea && keyCountEl) {
    keysTextarea.addEventListener('input', function() {
        var lines = this.value.split('\n').filter(function(l) { return l.trim(); }).length;
        keyCountEl.textContent = lines + ' key' + (lines !== 1 ? 's' : '') + ' ready to add';
    });
}
</script>

<?php
if (file_exists(__DIR__ . '/../includes/admin_footer.php')) {
    require_once __DIR__ . '/../includes/admin_footer.php';
} else {
?>
    </main>
</div>
<script src="/assets/js/main.js"></script>
</body>
</html>
<?php } ?>
