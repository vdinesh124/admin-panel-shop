<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $paymentId = (int)($_POST['payment_id'] ?? 0);

    if ($action === 'approve' && $paymentId) {
        $stmt = $pdo->prepare("SELECT * FROM payment_sessions WHERE id = ? AND status = 'pending'");
        $stmt->execute([$paymentId]);
        $session = $stmt->fetch();

        if ($session) {
            $pdo->prepare("UPDATE payment_sessions SET status = 'completed' WHERE id = ?")->execute([$paymentId]);
            addWalletTransaction($session['user_id'], $session['amount'], 'credit', 'UPI deposit approved');
            $message = 'Payment approved and wallet credited';
            $messageType = 'success';
        } else {
            $message = 'Payment not found or already processed';
            $messageType = 'error';
        }
    }

    if ($action === 'reject' && $paymentId) {
        $stmt = $pdo->prepare("SELECT * FROM payment_sessions WHERE id = ? AND status = 'pending'");
        $stmt->execute([$paymentId]);
        $session = $stmt->fetch();

        if ($session) {
            $pdo->prepare("UPDATE payment_sessions SET status = 'rejected' WHERE id = ?")->execute([$paymentId]);
            $message = 'Payment rejected';
            $messageType = 'success';
        } else {
            $message = 'Payment not found or already processed';
            $messageType = 'error';
        }
    }

    header("Location: /admin/payments.php" . ($message ? "?msg=" . urlencode($message) . "&type=$messageType" : ""));
    exit;
}

if (isset($_GET['msg'])) {
    $message = $_GET['msg'];
    $messageType = $_GET['type'] ?? 'success';
}

$sessions = $pdo->query("
    SELECT ps.*, u.username
    FROM payment_sessions ps
    LEFT JOIN users u ON ps.user_id = u.id
    ORDER BY
        CASE WHEN ps.status = 'pending' THEN 0 ELSE 1 END,
        ps.created_at DESC
    LIMIT 200
")->fetchAll();

$pendingPayments = 0;
foreach ($sessions as $s) {
    if ($s['status'] === 'pending') $pendingPayments++;
}

if (file_exists(__DIR__ . '/../includes/admin_header.php')) {
    require_once __DIR__ . '/../includes/admin_header.php';
} else {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payments - Admin - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="admin-sidebar-header">
            <h2><?= SITE_NAME ?></h2>
            <span class="text-muted text-xs">ADMIN</span>
        </div>
        <nav class="admin-nav">
            <a href="/admin/index.php" class="admin-nav-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                Dashboard
            </a>
            <a href="/admin/products.php" class="admin-nav-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
                Products
            </a>
            <a href="/admin/keys.php" class="admin-nav-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>
                License Keys
            </a>
            <a href="/admin/users.php" class="admin-nav-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                Users
            </a>
            <a href="/admin/payments.php" class="admin-nav-item active">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                Payments
                <?php if ($pendingPayments > 0): ?><span class="admin-badge-count"><?= $pendingPayments ?></span><?php endif; ?>
            </a>
            <a href="/admin/index.php?logout=1" class="admin-nav-item admin-nav-logout">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                Logout
            </a>
        </nav>
    </aside>
    <main class="admin-main">
<?php } ?>

<div class="admin-page-header">
    <div class="admin-page-title-row">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="text-primary"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
        <h1 data-testid="text-admin-payments-title">UPI Payments</h1>
    </div>
</div>

<?php if ($message): ?>
    <div class="alert alert-<?= $messageType ?>"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<?php if (empty($sessions)): ?>
    <div class="card text-center" style="padding: 40px;">
        <p class="text-muted">No payment sessions yet</p>
    </div>
<?php else: ?>
    <div class="payments-list">
        <?php foreach ($sessions as $s): ?>
            <div class="card payment-card" data-testid="card-payment-<?= $s['id'] ?>" style="margin-bottom: 12px;">
                <div class="card-body">
                    <div class="payment-card-row">
                        <div class="payment-card-info">
                            <div class="payment-meta">
                                <span class="font-semibold text-sm" data-testid="text-payment-user-<?= $s['id'] ?>"><?= htmlspecialchars($s['username'] ?? 'User #' . $s['user_id']) ?></span>
                                <?php
                                    $statusClass = 'outline';
                                    $statusIcon = '';
                                    $statusColor = '';
                                    switch ($s['status']) {
                                        case 'pending':
                                            $statusClass = 'warning';
                                            $statusColor = 'text-yellow';
                                            break;
                                        case 'completed':
                                            $statusClass = 'success';
                                            $statusColor = 'text-green';
                                            break;
                                        case 'failed':
                                        case 'rejected':
                                            $statusClass = 'danger';
                                            $statusColor = 'text-red';
                                            break;
                                    }
                                ?>
                                <span class="badge badge-<?= $statusClass ?> badge-sm"><?= ucfirst($s['status']) ?></span>
                            </div>
                            <p class="text-lg font-bold" data-testid="text-payment-amount-<?= $s['id'] ?>"><?= formatINR($s['amount']) ?></p>
                            <p class="text-muted text-xs">Ref: <?= htmlspecialchars($s['transaction_ref'] ?? '-') ?></p>
                            <?php if (!empty($s['utr'])): ?>
                                <p class="text-cyan text-xs font-semibold">UTR: <?= htmlspecialchars($s['utr']) ?></p>
                            <?php endif; ?>
                            <p class="text-muted text-xs"><?= date('M j, Y g:i A', strtotime($s['created_at'])) ?></p>
                        </div>

                        <?php if ($s['status'] === 'pending'): ?>
                            <div class="payment-card-actions">
                                <form method="POST" style="display:inline">
                                    <input type="hidden" name="action" value="approve">
                                    <input type="hidden" name="payment_id" value="<?= $s['id'] ?>">
                                    <button type="submit" class="btn-sm btn-success" data-testid="button-approve-<?= $s['id'] ?>">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                                        Approve
                                    </button>
                                </form>
                                <form method="POST" style="display:inline">
                                    <input type="hidden" name="action" value="reject">
                                    <input type="hidden" name="payment_id" value="<?= $s['id'] ?>">
                                    <button type="submit" class="btn-sm btn-danger" data-testid="button-reject-<?= $s['id'] ?>">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
                                        Reject
                                    </button>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php
if (file_exists(__DIR__ . '/../includes/admin_footer.php')) {
    require_once __DIR__ . '/../includes/admin_footer.php';
} else {
?>
    </main>
</div>
<script src="/assets/js/main.js"></script>
</body>
</html>
<?php } ?>
