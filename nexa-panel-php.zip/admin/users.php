<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'adjust_balance') {
        $userId = (int)$_POST['user_id'];
        $amount = (float)$_POST['amount'];
        $type = $_POST['type'] ?? 'credit';
        $description = "Admin " . ($type === 'credit' ? 'credit' : 'debit') . ": " . formatINR($amount);

        if ($userId && $amount > 0) {
            if ($type === 'debit') {
                $balance = getWalletBalance($userId);
                if ($balance < $amount) {
                    $message = 'Insufficient balance for debit';
                    $messageType = 'error';
                } else {
                    addWalletTransaction($userId, $amount, 'debit', $description);
                    $message = 'Balance deducted successfully';
                    $messageType = 'success';
                }
            } else {
                addWalletTransaction($userId, $amount, 'credit', $description);
                $message = 'Balance added successfully';
                $messageType = 'success';
            }
        }
    }

    header("Location: /admin/users.php" . ($message ? "?msg=" . urlencode($message) . "&type=$messageType" : ""));
    exit;
}

if (isset($_GET['msg'])) {
    $message = $_GET['msg'];
    $messageType = $_GET['type'] ?? 'success';
}

$users = $pdo->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();
foreach ($users as &$u) {
    $u['wallet_balance'] = getWalletBalance($u['id']);
    $u['total_purchases'] = getUserPurchaseCount($u['id']);
}
unset($u);

$pendingPayments = (int)$pdo->query("SELECT COUNT(*) FROM payment_sessions WHERE status = 'pending'")->fetchColumn();

if (file_exists(__DIR__ . '/../includes/admin_header.php')) {
    require_once __DIR__ . '/../includes/admin_header.php';
} else {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users - Admin - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="admin-sidebar-header">
            <h2><?= SITE_NAME ?></h2>
            <span class="text-muted text-xs">ADMIN</span>
        </div>
        <nav class="admin-nav">
            <a href="/admin/index.php" class="admin-nav-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                Dashboard
            </a>
            <a href="/admin/products.php" class="admin-nav-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
                Products
            </a>
            <a href="/admin/keys.php" class="admin-nav-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>
                License Keys
            </a>
            <a href="/admin/users.php" class="admin-nav-item active">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                Users
            </a>
            <a href="/admin/payments.php" class="admin-nav-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                Payments
                <?php if ($pendingPayments > 0): ?><span class="admin-badge-count"><?= $pendingPayments ?></span><?php endif; ?>
            </a>
            <a href="/admin/index.php?logout=1" class="admin-nav-item admin-nav-logout">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                Logout
            </a>
        </nav>
    </aside>
    <main class="admin-main">
<?php } ?>

<div class="admin-page-header">
    <h1 data-testid="text-admin-users-title">Manage Users</h1>
    <span class="badge badge-secondary"><?= count($users) ?> Users</span>
</div>

<?php if ($message): ?>
    <div class="alert alert-<?= $messageType ?>"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<?php if (empty($users)): ?>
    <div class="card text-center" style="padding: 40px;">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin: 0 auto 8px; opacity: 0.5"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
        <p class="text-muted">No users registered yet.</p>
    </div>
<?php else: ?>
    <div class="users-list">
        <?php foreach ($users as $u): ?>
            <div class="card user-card" data-testid="card-admin-user-<?= $u['id'] ?>" style="margin-bottom: 8px;">
                <div class="card-body">
                    <div class="user-card-row">
                        <div class="user-card-info">
                            <div class="user-avatar">
                                <?= strtoupper(substr($u['username'] ?? 'U', 0, 1)) ?>
                            </div>
                            <div>
                                <p class="font-semibold text-sm" data-testid="text-user-name-<?= $u['id'] ?>">
                                    <?= htmlspecialchars($u['first_name'] ? trim($u['first_name'] . ' ' . ($u['last_name'] ?? '')) : ($u['username'] ?? 'User #' . $u['id'])) ?>
                                </p>
                                <p class="text-muted text-xs"><?= htmlspecialchars($u['email'] ?: $u['username']) ?></p>
                            </div>
                        </div>
                        <div class="user-card-actions">
                            <div class="text-right">
                                <p class="font-bold text-sm" data-testid="text-user-balance-<?= $u['id'] ?>"><?= formatINR($u['wallet_balance']) ?></p>
                                <p class="text-muted text-xs"><?= $u['total_purchases'] ?> purchases</p>
                            </div>
                            <button class="btn-sm btn-outline" onclick="toggleAdjust(<?= $u['id'] ?>)" data-testid="button-adjust-balance-<?= $u['id'] ?>">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                                Adjust
                            </button>
                        </div>
                    </div>

                    <div id="adjustBalance<?= $u['id'] ?>" style="display:none;" class="adjust-balance-form">
                        <form method="POST" class="form-inline">
                            <input type="hidden" name="action" value="adjust_balance">
                            <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                            <select name="type" class="input-field input-sm" data-testid="select-balance-type">
                                <option value="credit">Add Balance</option>
                                <option value="debit">Deduct Balance</option>
                            </select>
                            <input type="number" name="amount" placeholder="Amount" step="0.01" min="0.01" required class="input-field input-sm" style="width: 120px;" data-testid="input-balance-amount">
                            <button type="submit" class="btn-primary btn-sm" data-testid="button-confirm-adjust">Confirm</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<script>
function toggleAdjust(id) {
    var el = document.getElementById('adjustBalance' + id);
    el.style.display = el.style.display === 'none' ? 'flex' : 'none';
}
</script>

<?php
if (file_exists(__DIR__ . '/../includes/admin_footer.php')) {
    require_once __DIR__ . '/../includes/admin_footer.php';
} else {
?>
    </main>
</div>
<script src="/assets/js/main.js"></script>
</body>
</html>
<?php } ?>
