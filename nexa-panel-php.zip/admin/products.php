<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create_product') {
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $features = array_filter(array_map('trim', explode("\n", $_POST['features'] ?? '')));
        $videoUrl = trim($_POST['video_url'] ?? '');
        $category = $_POST['category'] ?? 'mobile';
        $status = $_POST['status'] ?? 'active';
        $updateUrl = trim($_POST['update_url'] ?? '');

        if ($name && $description) {
            $stmt = $pdo->prepare("INSERT INTO products (name, description, features, image_url, video_url, category, status, update_url, created_at) VALUES (?, ?, ?, '', ?, ?, ?, ?, NOW())");
            $stmt->execute([$name, $description, json_encode(array_values($features)), $videoUrl, $category, $status, $updateUrl]);
            $message = 'Product created successfully';
            $messageType = 'success';
        }
    }

    if ($action === 'update_product') {
        $id = (int)$_POST['product_id'];
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $features = array_filter(array_map('trim', explode("\n", $_POST['features'] ?? '')));
        $videoUrl = trim($_POST['video_url'] ?? '');
        $category = $_POST['category'] ?? 'mobile';
        $status = $_POST['status'] ?? 'active';
        $updateUrl = trim($_POST['update_url'] ?? '');

        $stmt = $pdo->prepare("UPDATE products SET name=?, description=?, features=?, video_url=?, category=?, status=?, update_url=? WHERE id=?");
        $stmt->execute([$name, $description, json_encode(array_values($features)), $videoUrl, $category, $status, $updateUrl, $id]);
        $message = 'Product updated successfully';
        $messageType = 'success';
    }

    if ($action === 'delete_product') {
        $id = (int)$_POST['product_id'];
        $pdo->prepare("DELETE FROM products WHERE id = ?")->execute([$id]);
        $message = 'Product deleted';
        $messageType = 'success';
    }

    if ($action === 'add_tier') {
        $productId = (int)$_POST['product_id'];
        $label = trim($_POST['label'] ?? '');
        $price = (float)$_POST['price'];
        $sortOrder = (int)($_POST['sort_order'] ?? 0);

        if ($label && $price > 0) {
            $stmt = $pdo->prepare("INSERT INTO pricing_tiers (product_id, label, price, sort_order) VALUES (?, ?, ?, ?)");
            $stmt->execute([$productId, $label, $price, $sortOrder]);
            $message = 'Tier added successfully';
            $messageType = 'success';
        }
    }

    if ($action === 'update_tier') {
        $tierId = (int)$_POST['tier_id'];
        $label = trim($_POST['label'] ?? '');
        $price = (float)$_POST['price'];

        if ($label && $price > 0) {
            $stmt = $pdo->prepare("UPDATE pricing_tiers SET label=?, price=? WHERE id=?");
            $stmt->execute([$label, $price, $tierId]);
            $message = 'Tier updated';
            $messageType = 'success';
        }
    }

    if ($action === 'delete_tier') {
        $tierId = (int)$_POST['tier_id'];
        $pdo->prepare("DELETE FROM pricing_tiers WHERE id = ?")->execute([$tierId]);
        $message = 'Tier deleted';
        $messageType = 'success';
    }

    header("Location: /admin/products.php" . ($message ? "?msg=" . urlencode($message) . "&type=$messageType" : ""));
    exit;
}

if (isset($_GET['msg'])) {
    $message = $_GET['msg'];
    $messageType = $_GET['type'] ?? 'success';
}

$products = $pdo->query("SELECT * FROM products ORDER BY id DESC")->fetchAll();
foreach ($products as &$p) {
    $stmt = $pdo->prepare("SELECT * FROM pricing_tiers WHERE product_id = ? ORDER BY sort_order, price");
    $stmt->execute([$p['id']]);
    $p['tiers'] = $stmt->fetchAll();
    $p['features'] = json_decode($p['features'] ?? '[]', true) ?: [];

    foreach ($p['tiers'] as &$t) {
        $stmt2 = $pdo->prepare("SELECT COUNT(*) as total, SUM(CASE WHEN status='available' THEN 1 ELSE 0 END) as available FROM license_keys WHERE tier_id = ?");
        $stmt2->execute([$t['id']]);
        $stock = $stmt2->fetch();
        $t['total_keys'] = (int)($stock['total'] ?? 0);
        $t['available_keys'] = (int)($stock['available'] ?? 0);
    }
}
unset($p, $t);

$pendingPayments = (int)$pdo->query("SELECT COUNT(*) FROM payment_sessions WHERE status = 'pending'")->fetchColumn();

if (file_exists(__DIR__ . '/../includes/admin_header.php')) {
    require_once __DIR__ . '/../includes/admin_header.php';
} else {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - Admin - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="admin-sidebar-header">
            <h2><?= SITE_NAME ?></h2>
            <span class="text-muted text-xs">ADMIN</span>
        </div>
        <nav class="admin-nav">
            <a href="/admin/index.php" class="admin-nav-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                Dashboard
            </a>
            <a href="/admin/products.php" class="admin-nav-item active">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
                Products
            </a>
            <a href="/admin/keys.php" class="admin-nav-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>
                License Keys
            </a>
            <a href="/admin/users.php" class="admin-nav-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                Users
            </a>
            <a href="/admin/payments.php" class="admin-nav-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                Payments
                <?php if ($pendingPayments > 0): ?><span class="admin-badge-count"><?= $pendingPayments ?></span><?php endif; ?>
            </a>
            <a href="/admin/index.php?logout=1" class="admin-nav-item admin-nav-logout">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                Logout
            </a>
        </nav>
    </aside>
    <main class="admin-main">
<?php } ?>

<div class="admin-page-header">
    <h1 data-testid="text-admin-products-title">Manage Products</h1>
    <button class="btn-primary" onclick="document.getElementById('addProductForm').style.display = document.getElementById('addProductForm').style.display === 'none' ? 'block' : 'none'" data-testid="button-add-product">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        Add Product
    </button>
</div>

<?php if ($message): ?>
    <div class="alert alert-<?= $messageType ?>"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<div id="addProductForm" class="card" style="display:none; margin-bottom: 16px;">
    <div class="card-body">
        <h3 class="card-title">New Product</h3>
        <form method="POST">
            <input type="hidden" name="action" value="create_product">
            <div class="form-group">
                <input type="text" name="name" placeholder="Product Name" required class="input-field" data-testid="input-product-name">
            </div>
            <div class="form-group">
                <input type="text" name="description" placeholder="Description" required class="input-field" data-testid="input-product-description">
            </div>
            <div class="form-group">
                <textarea name="features" placeholder="Features (one per line)" rows="4" class="input-field" data-testid="input-product-features"></textarea>
            </div>
            <div class="form-group">
                <input type="text" name="video_url" placeholder="Video URL (optional)" class="input-field">
            </div>
            <div class="form-group">
                <input type="text" name="update_url" placeholder="Update / Join URL (optional)" class="input-field">
            </div>
            <div class="form-group">
                <label class="form-label">Category</label>
                <select name="category" class="input-field" data-testid="select-product-category">
                    <option value="mobile">Mobile Panel</option>
                    <option value="pc">PC Panel</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Status</label>
                <select name="status" class="input-field">
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn-primary" data-testid="button-save-product">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                    Save
                </button>
                <button type="button" class="btn-outline" onclick="document.getElementById('addProductForm').style.display='none'">Cancel</button>
            </div>
        </form>
    </div>
</div>

<?php if (empty($products)): ?>
    <div class="card text-center" style="padding: 40px;">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin: 0 auto 8px; opacity: 0.5"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
        <p class="text-muted">No products yet. Add your first product above.</p>
    </div>
<?php else: ?>
    <?php foreach ($products as $p): ?>
        <div class="card product-admin-card" data-testid="card-admin-product-<?= $p['id'] ?>" style="margin-bottom: 16px;">
            <div class="card-body">
                <div class="product-admin-header">
                    <div class="product-admin-info">
                        <div class="product-admin-icon">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
                        </div>
                        <div>
                            <h3 class="product-admin-name" data-testid="text-product-name-<?= $p['id'] ?>"><?= htmlspecialchars($p['name']) ?></h3>
                            <p class="text-muted text-xs"><?= htmlspecialchars($p['description']) ?></p>
                        </div>
                    </div>
                    <div class="product-admin-actions">
                        <span class="badge badge-<?= $p['status'] === 'active' ? 'success' : 'secondary' ?>"><?= $p['status'] ?></span>
                        <button class="btn-icon" onclick="toggleEdit(<?= $p['id'] ?>)" data-testid="button-edit-product-<?= $p['id'] ?>">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                        </button>
                        <form method="POST" style="display:inline" onsubmit="return confirm('Delete this product?')">
                            <input type="hidden" name="action" value="delete_product">
                            <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                            <button type="submit" class="btn-icon btn-danger" data-testid="button-delete-product-<?= $p['id'] ?>">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                            </button>
                        </form>
                    </div>
                </div>

                <div id="editProduct<?= $p['id'] ?>" style="display:none;" class="edit-product-form">
                    <form method="POST">
                        <input type="hidden" name="action" value="update_product">
                        <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                        <div class="form-group">
                            <input type="text" name="name" value="<?= htmlspecialchars($p['name']) ?>" class="input-field" required>
                        </div>
                        <div class="form-group">
                            <input type="text" name="description" value="<?= htmlspecialchars($p['description']) ?>" class="input-field">
                        </div>
                        <div class="form-group">
                            <textarea name="features" rows="3" class="input-field"><?= htmlspecialchars(implode("\n", $p['features'])) ?></textarea>
                        </div>
                        <div class="form-group">
                            <input type="text" name="video_url" value="<?= htmlspecialchars($p['video_url'] ?? '') ?>" placeholder="Video URL" class="input-field">
                        </div>
                        <div class="form-group">
                            <input type="text" name="update_url" value="<?= htmlspecialchars($p['update_url'] ?? '') ?>" placeholder="Update URL" class="input-field">
                        </div>
                        <div class="form-row">
                            <select name="category" class="input-field">
                                <option value="mobile" <?= ($p['category'] ?? '') === 'mobile' ? 'selected' : '' ?>>Mobile Panel</option>
                                <option value="pc" <?= ($p['category'] ?? '') === 'pc' ? 'selected' : '' ?>>PC Panel</option>
                            </select>
                            <select name="status" class="input-field">
                                <option value="active" <?= $p['status'] === 'active' ? 'selected' : '' ?>>Active</option>
                                <option value="inactive" <?= $p['status'] !== 'active' ? 'selected' : '' ?>>Inactive</option>
                            </select>
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn-primary">Save</button>
                            <button type="button" class="btn-outline" onclick="toggleEdit(<?= $p['id'] ?>)">Cancel</button>
                        </div>
                    </form>
                </div>

                <div class="tiers-section">
                    <div class="tiers-header">
                        <p class="section-label">PRICING TIERS</p>
                        <button class="btn-sm btn-outline" onclick="toggleAddTier(<?= $p['id'] ?>)">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                            Add Tier
                        </button>
                    </div>

                    <div id="addTier<?= $p['id'] ?>" style="display:none;" class="add-tier-form">
                        <form method="POST" class="form-inline">
                            <input type="hidden" name="action" value="add_tier">
                            <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                            <input type="text" name="label" placeholder="Tier Label (e.g. 1 Day)" required class="input-field input-sm">
                            <input type="number" name="price" placeholder="Price" required step="0.01" class="input-field input-sm">
                            <input type="number" name="sort_order" placeholder="Order" value="0" class="input-field input-sm" style="width: 80px;">
                            <button type="submit" class="btn-primary btn-sm">Add</button>
                        </form>
                    </div>

                    <?php if (empty($p['tiers'])): ?>
                        <p class="text-muted text-xs" style="padding: 8px 0;">No pricing tiers yet</p>
                    <?php else: ?>
                        <?php foreach ($p['tiers'] as $t): ?>
                            <div class="tier-row" data-testid="tier-row-<?= $t['id'] ?>">
                                <div class="tier-info">
                                    <span class="tier-label"><?= htmlspecialchars($t['label']) ?></span>
                                    <span class="tier-price"><?= formatINR($t['price']) ?></span>
                                    <span class="badge badge-<?= $t['available_keys'] > 0 ? 'success' : 'danger' ?> badge-sm">
                                        <?= $t['available_keys'] ?> / <?= $t['total_keys'] ?> keys
                                    </span>
                                </div>
                                <div class="tier-actions">
                                    <button class="btn-icon btn-xs" onclick="toggleEditTier(<?= $t['id'] ?>)" title="Edit tier">
                                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                                    </button>
                                    <form method="POST" style="display:inline" onsubmit="return confirm('Delete this tier?')">
                                        <input type="hidden" name="action" value="delete_tier">
                                        <input type="hidden" name="tier_id" value="<?= $t['id'] ?>">
                                        <button type="submit" class="btn-icon btn-danger btn-xs" title="Delete tier">
                                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                                        </button>
                                    </form>
                                </div>
                            </div>
                            <div id="editTier<?= $t['id'] ?>" style="display:none;" class="edit-tier-form">
                                <form method="POST" class="form-inline">
                                    <input type="hidden" name="action" value="update_tier">
                                    <input type="hidden" name="tier_id" value="<?= $t['id'] ?>">
                                    <input type="text" name="label" value="<?= htmlspecialchars($t['label']) ?>" required class="input-field input-sm">
                                    <input type="number" name="price" value="<?= $t['price'] ?>" required step="0.01" class="input-field input-sm">
                                    <button type="submit" class="btn-primary btn-sm">Save</button>
                                    <button type="button" class="btn-outline btn-sm" onclick="toggleEditTier(<?= $t['id'] ?>)">Cancel</button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<script>
function toggleEdit(id) {
    var el = document.getElementById('editProduct' + id);
    el.style.display = el.style.display === 'none' ? 'block' : 'none';
}
function toggleAddTier(id) {
    var el = document.getElementById('addTier' + id);
    el.style.display = el.style.display === 'none' ? 'block' : 'none';
}
function toggleEditTier(id) {
    var el = document.getElementById('editTier' + id);
    el.style.display = el.style.display === 'none' ? 'flex' : 'none';
}
</script>

<?php
if (file_exists(__DIR__ . '/../includes/admin_footer.php')) {
    require_once __DIR__ . '/../includes/admin_footer.php';
} else {
?>
    </main>
</div>
<script src="/assets/js/main.js"></script>
</body>
</html>
<?php } ?>
