<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_login'])) {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    if ($username === ADMIN_USERNAME && $password === ADMIN_PASSWORD) {
        $_SESSION['is_admin'] = true;
        $_SESSION['admin_user'] = $username;
        header("Location: /admin/index.php");
        exit;
    } else {
        $loginError = "Invalid username or password";
    }
}

if (isset($_GET['logout'])) {
    unset($_SESSION['is_admin']);
    unset($_SESSION['admin_user']);
    header("Location: /admin/index.php");
    exit;
}

if (!isAdmin()) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="admin-login-wrap">
    <div class="admin-login-box">
        <div class="admin-login-icon">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
        </div>
        <h1>ADMIN <span class="text-primary">PANEL</span></h1>
        <p class="text-muted">Authorize Access</p>

        <?php if (!empty($loginError)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($loginError) ?></div>
        <?php endif; ?>

        <form method="POST" class="admin-login-form">
            <div class="input-group">
                <svg class="input-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                <input type="text" name="username" placeholder="Username" required class="input-field" data-testid="input-admin-username">
            </div>
            <div class="input-group">
                <svg class="input-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                <input type="password" name="password" placeholder="Password" required class="input-field" data-testid="input-admin-password">
            </div>
            <button type="submit" name="admin_login" class="btn-primary btn-block" data-testid="button-admin-login">LOGIN NOW</button>
        </form>
    </div>
</div>
</body>
</html>
<?php
    exit;
}

$totalUsers = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalProducts = (int)$pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$totalPurchases = (int)$pdo->query("SELECT COUNT(*) FROM purchases")->fetchColumn();
$totalRevenue = (float)$pdo->query("SELECT COALESCE(SUM(amount), 0) FROM purchases")->fetchColumn();
$pendingPayments = (int)$pdo->query("SELECT COUNT(*) FROM payment_sessions WHERE status = 'pending'")->fetchColumn();
$totalKeys = (int)$pdo->query("SELECT COUNT(*) FROM license_keys")->fetchColumn();
$availableKeys = (int)$pdo->query("SELECT COUNT(*) FROM license_keys WHERE status = 'available'")->fetchColumn();

if (file_exists(__DIR__ . '/../includes/admin_header.php')) {
    require_once __DIR__ . '/../includes/admin_header.php';
} else {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<div class="admin-layout">
    <aside class="admin-sidebar">
        <div class="admin-sidebar-header">
            <h2><?= SITE_NAME ?></h2>
            <span class="text-muted text-xs">ADMIN</span>
        </div>
        <nav class="admin-nav">
            <a href="/admin/index.php" class="admin-nav-item active">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                Dashboard
            </a>
            <a href="/admin/products.php" class="admin-nav-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
                Products
            </a>
            <a href="/admin/keys.php" class="admin-nav-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>
                License Keys
            </a>
            <a href="/admin/users.php" class="admin-nav-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                Users
            </a>
            <a href="/admin/payments.php" class="admin-nav-item">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                Payments
                <?php if ($pendingPayments > 0): ?><span class="admin-badge-count"><?= $pendingPayments ?></span><?php endif; ?>
            </a>
            <a href="/admin/index.php?logout=1" class="admin-nav-item admin-nav-logout">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                Logout
            </a>
        </nav>
    </aside>
    <main class="admin-main">
<?php } ?>

<div class="admin-page-header">
    <h1 data-testid="text-admin-dashboard-title">Admin Dashboard</h1>
</div>

<div class="stats-grid">
    <div class="stat-card stat-card-blue">
        <div class="stat-card-header">
            <span class="stat-label">Total Users</span>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="stat-icon text-blue"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
        </div>
        <p class="stat-value" data-testid="text-admin-stat-total-users"><?= $totalUsers ?></p>
    </div>
    <div class="stat-card stat-card-green">
        <div class="stat-card-header">
            <span class="stat-label">Total Products</span>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="stat-icon text-green"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
        </div>
        <p class="stat-value" data-testid="text-admin-stat-total-products"><?= $totalProducts ?></p>
    </div>
    <div class="stat-card stat-card-purple">
        <div class="stat-card-header">
            <span class="stat-label">Total Purchases</span>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="stat-icon text-purple"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
        </div>
        <p class="stat-value" data-testid="text-admin-stat-total-purchases"><?= $totalPurchases ?></p>
    </div>
    <div class="stat-card stat-card-amber">
        <div class="stat-card-header">
            <span class="stat-label">Total Revenue</span>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="stat-icon text-amber"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
        </div>
        <p class="stat-value" data-testid="text-admin-stat-total-revenue"><?= formatINR($totalRevenue) ?></p>
    </div>
</div>

<div class="stats-grid stats-grid-secondary">
    <div class="stat-card">
        <div class="stat-card-header">
            <span class="stat-label">Pending Payments</span>
        </div>
        <p class="stat-value text-yellow"><?= $pendingPayments ?></p>
    </div>
    <div class="stat-card">
        <div class="stat-card-header">
            <span class="stat-label">Available Keys</span>
        </div>
        <p class="stat-value"><?= $availableKeys ?> / <?= $totalKeys ?></p>
    </div>
</div>

<?php
if (file_exists(__DIR__ . '/../includes/admin_footer.php')) {
    require_once __DIR__ . '/../includes/admin_footer.php';
} else {
?>
    </main>
</div>
<script src="/assets/js/main.js"></script>
</body>
</html>
<?php } ?>
