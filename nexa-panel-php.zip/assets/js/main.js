document.addEventListener('DOMContentLoaded', function () {

  var sidebar = document.querySelector('.sidebar, .admin-sidebar');
  var overlay = document.querySelector('.sidebar-overlay');
  var toggleBtns = document.querySelectorAll('.hamburger-btn, [data-toggle-sidebar]');

  function isMobile() {
    return window.innerWidth <= 768;
  }

  function openSidebar() {
    if (!sidebar) return;
    sidebar.classList.add('open');
    sidebar.classList.remove('collapsed');
    if (overlay) overlay.classList.add('show');
  }

  function closeSidebar() {
    if (!sidebar) return;
    if (isMobile()) {
      sidebar.classList.remove('open');
    } else {
      sidebar.classList.toggle('collapsed');
    }
    if (overlay) overlay.classList.remove('show');
  }

  toggleBtns.forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      if (sidebar.classList.contains('open') && isMobile()) {
        closeSidebar();
      } else if (isMobile()) {
        openSidebar();
      } else {
        sidebar.classList.toggle('collapsed');
        var main = document.querySelector('.main-content');
        if (main) {
          main.style.marginLeft = sidebar.classList.contains('collapsed') ? '0' : 'var(--sidebar-width)';
        }
      }
    });
  });

  if (overlay) {
    overlay.addEventListener('click', closeSidebar);
  }

  window.addEventListener('resize', function () {
    if (!isMobile() && sidebar) {
      sidebar.classList.remove('open');
      if (overlay) overlay.classList.remove('show');
    }
  });

  window.copyToClipboard = function (text, btnEl) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () {
        showCopyFeedback(btnEl);
      }).catch(function () {
        fallbackCopy(text, btnEl);
      });
    } else {
      fallbackCopy(text, btnEl);
    }
  };

  function fallbackCopy(text, btnEl) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.left = '-9999px';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    try {
      document.execCommand('copy');
      showCopyFeedback(btnEl);
    } catch (e) {
      showToast('Failed to copy', '', 'error');
    }
    document.body.removeChild(ta);
  }

  function showCopyFeedback(btnEl) {
    if (!btnEl) {
      showToast('Copied!', '', 'success');
      return;
    }
    btnEl.classList.add('copied');
    var origHTML = btnEl.innerHTML;
    btnEl.innerHTML = '&#10003;';
    setTimeout(function () {
      btnEl.classList.remove('copied');
      btnEl.innerHTML = origHTML;
    }, 2000);
  }

  var tabBtns = document.querySelectorAll('.tab-btn');
  var tabPanels = document.querySelectorAll('.tab-panel');

  tabBtns.forEach(function (btn) {
    btn.addEventListener('click', function () {
      var target = btn.getAttribute('data-tab');

      tabBtns.forEach(function (b) {
        b.classList.remove('active-upi', 'active-crypto', 'active');
      });

      if (target === 'upi') {
        btn.classList.add('active-upi');
      } else if (target === 'crypto') {
        btn.classList.add('active-crypto');
      } else {
        btn.classList.add('active');
      }

      tabPanels.forEach(function (panel) {
        if (panel.getAttribute('data-tab-panel') === target) {
          panel.style.display = '';
        } else {
          panel.style.display = 'none';
        }
      });
    });
  });

  window.validateForm = function (formEl) {
    var valid = true;
    var required = formEl.querySelectorAll('[required]');
    required.forEach(function (field) {
      clearFieldError(field);
      if (!field.value || !field.value.trim()) {
        showFieldError(field, 'This field is required');
        valid = false;
      }
    });

    var emailFields = formEl.querySelectorAll('input[type="email"]');
    emailFields.forEach(function (field) {
      if (field.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(field.value)) {
        showFieldError(field, 'Invalid email address');
        valid = false;
      }
    });

    var passwordConfirm = formEl.querySelector('[data-confirm-password]');
    if (passwordConfirm) {
      var passwordField = formEl.querySelector('[data-password]');
      if (passwordField && passwordConfirm.value !== passwordField.value) {
        showFieldError(passwordConfirm, 'Passwords do not match');
        valid = false;
      }
    }

    var minLengthFields = formEl.querySelectorAll('[data-minlength]');
    minLengthFields.forEach(function (field) {
      var min = parseInt(field.getAttribute('data-minlength'), 10);
      if (field.value && field.value.length < min) {
        showFieldError(field, 'Minimum ' + min + ' characters required');
        valid = false;
      }
    });

    return valid;
  };

  function showFieldError(field, message) {
    field.style.borderColor = 'rgba(239, 68, 68, 0.5)';
    var existing = field.parentNode.querySelector('.field-error');
    if (!existing) {
      var err = document.createElement('p');
      err.className = 'field-error';
      err.style.cssText = 'color:#ef4444;font-size:11px;margin-top:4px;font-weight:500;';
      err.textContent = message;
      field.parentNode.appendChild(err);
    }
  }

  function clearFieldError(field) {
    field.style.borderColor = '';
    var err = field.parentNode.querySelector('.field-error');
    if (err) err.remove();
  }

  var forms = document.querySelectorAll('form[data-validate]');
  forms.forEach(function (form) {
    form.addEventListener('submit', function (e) {
      if (!window.validateForm(form)) {
        e.preventDefault();
      }
    });
  });

  var toastContainer = null;

  window.showToast = function (title, message, type) {
    type = type || 'info';

    if (!toastContainer) {
      toastContainer = document.createElement('div');
      toastContainer.className = 'toast-container';
      document.body.appendChild(toastContainer);
    }

    var toast = document.createElement('div');
    toast.className = 'toast toast-' + type;

    var icons = {
      success: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',
      error: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
      info: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#00dcff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>'
    };

    toast.innerHTML =
      '<div style="flex-shrink:0;margin-top:2px;">' + (icons[type] || icons.info) + '</div>' +
      '<div style="flex:1;min-width:0;">' +
        '<div class="toast-title">' + escapeHtml(title) + '</div>' +
        (message ? '<div class="toast-message">' + escapeHtml(message) + '</div>' : '') +
      '</div>' +
      '<button class="toast-close" onclick="this.parentNode.remove()">&times;</button>';

    toastContainer.appendChild(toast);

    setTimeout(function () {
      toast.style.animation = 'toastSlideOut 0.3s ease-in forwards';
      setTimeout(function () { toast.remove(); }, 300);
    }, 4000);
  };

  function escapeHtml(str) {
    if (!str) return '';
    var div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  window.initSpinWheel = function (options) {
    var canvas = document.getElementById(options.canvasId);
    if (!canvas) return;

    var ctx = canvas.getContext('2d');
    var segments = options.segments || [
      { value: 100, color: '#6366f1', label: '₹100' },
      { value: 5, color: '#1e1e3a', label: '₹5' },
      { value: 20, color: '#6366f1', label: '₹20' },
      { value: 1, color: '#1e1e3a', label: '₹1' }
    ];

    var size = canvas.width;
    var center = size / 2;
    var radius = center - 10;
    var currentRotation = 0;
    var spinning = false;

    function drawWheel(rot) {
      ctx.clearRect(0, 0, size, size);
      ctx.save();
      ctx.translate(center, center);
      ctx.rotate((rot * Math.PI) / 180);

      var segAngle = (2 * Math.PI) / segments.length;

      segments.forEach(function (seg, i) {
        var startAngle = i * segAngle - Math.PI / 2;
        var endAngle = startAngle + segAngle;

        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.arc(0, 0, radius, startAngle, endAngle);
        ctx.closePath();
        ctx.fillStyle = seg.color;
        ctx.fill();
        ctx.strokeStyle = 'rgba(0,220,255,0.3)';
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.save();
        ctx.rotate(startAngle + segAngle / 2);
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 16px Inter, sans-serif';
        ctx.fillText(seg.label, radius * 0.6, 0);
        ctx.restore();
      });

      ctx.beginPath();
      ctx.arc(0, 0, 20, 0, 2 * Math.PI);
      ctx.fillStyle = '#111';
      ctx.fill();
      ctx.strokeStyle = 'rgba(0,220,255,0.5)';
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.restore();
    }

    drawWheel(0);

    window.spinWheel = function (prizeValue, callback) {
      if (spinning) return;
      spinning = true;

      var prizeIndex = 0;
      for (var i = 0; i < segments.length; i++) {
        if (segments[i].value === prizeValue) {
          prizeIndex = i;
          break;
        }
      }

      var segAngle = 360 / segments.length;
      var targetCenter = prizeIndex * segAngle + segAngle / 2;
      var spins = 5 + Math.floor(Math.random() * 3);
      var totalRotation = spins * 360 + (360 - targetCenter);

      var startTime = null;
      var duration = 4000;
      var startRot = currentRotation;

      function easeOut(t) {
        return 1 - Math.pow(1 - t, 3);
      }

      function animate(timestamp) {
        if (!startTime) startTime = timestamp;
        var elapsed = timestamp - startTime;
        var progress = Math.min(elapsed / duration, 1);
        var easedProgress = easeOut(progress);

        currentRotation = startRot + totalRotation * easedProgress;
        drawWheel(currentRotation);

        if (progress < 1) {
          requestAnimationFrame(animate);
        } else {
          spinning = false;
          if (callback) callback(prizeValue);
        }
      }

      requestAnimationFrame(animate);
    };
  };

  var amountBtns = document.querySelectorAll('[data-amount]');
  amountBtns.forEach(function (btn) {
    btn.addEventListener('click', function () {
      var amount = btn.getAttribute('data-amount');
      var input = document.querySelector('#deposit-amount, [name="amount"]');
      if (input) input.value = amount;
    });
  });

  var videos = document.querySelectorAll('.product-card video');
  videos.forEach(function (video) {
    video.muted = true;
    var playBtn = video.parentNode.querySelector('.play-btn');
    if (playBtn) {
      playBtn.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        if (video.paused) {
          video.muted = false;
          video.play().catch(function () {});
          playBtn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>';
        } else {
          video.pause();
          video.muted = true;
          playBtn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>';
        }
      });
    }
  });

  var expandBtns = document.querySelectorAll('[data-expand-features]');
  expandBtns.forEach(function (btn) {
    btn.addEventListener('click', function () {
      var target = document.getElementById(btn.getAttribute('data-expand-features'));
      if (!target) return;
      var hidden = target.querySelectorAll('.feature-hidden');
      var isExpanded = btn.getAttribute('data-expanded') === 'true';

      hidden.forEach(function (el) {
        el.style.display = isExpanded ? 'none' : '';
      });

      btn.setAttribute('data-expanded', isExpanded ? 'false' : 'true');
      var chevron = btn.querySelector('.chevron');
      if (chevron) {
        chevron.style.transform = isExpanded ? '' : 'rotate(180deg)';
      }
    });
  });

  var tierToggles = document.querySelectorAll('[data-toggle-tiers]');
  tierToggles.forEach(function (btn) {
    btn.addEventListener('click', function () {
      var target = document.getElementById(btn.getAttribute('data-toggle-tiers'));
      if (!target) return;
      var isVisible = target.style.display !== 'none';
      target.style.display = isVisible ? 'none' : '';
      if (!isVisible) {
        target.style.animation = 'slideDown 0.3s ease-out both';
      }
    });
  });

  if (typeof window.onPaymentPageLoad === 'function') {
    window.onPaymentPageLoad();
  }
});
