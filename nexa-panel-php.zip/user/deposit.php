<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireLogin();

$user = getCurrentUser();
$balance = getWalletBalance($user['id']);
$todayDeposit = getTodayDeposit($user['id']);

$activeSession = null;
$stmt = $pdo->prepare("SELECT * FROM payment_sessions WHERE user_id = ? AND status = 'pending' AND created_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE) ORDER BY id DESC LIMIT 1");
$stmt->execute([$user['id']]);
$activeSession = $stmt->fetch();

$pageTitle = 'Deposit';
include __DIR__ . '/../includes/header.php';
?>

<div class="max-w-md mx-auto px-4 py-4 space-y-4" id="deposit-page">

    <div class="balance-card" style="border: 2px solid #00e5bf; box-shadow: 0 0 15px rgba(0,229,191,0.25), 0 0 30px rgba(0,229,191,0.1), 0 0 60px rgba(0,229,191,0.05); text-align:center; padding: 20px; border-radius: 16px; background: #0d1424;">
        <p style="font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:3px; color:#8b9dc3; margin-bottom:6px;">Current Balance</p>
        <p style="font-size:28px; font-weight:800; color:#fff;" data-testid="text-deposit-balance"><?php echo formatINR($balance); ?></p>
    </div>

    <div class="balance-card" style="border: 2px solid #00e5bf; box-shadow: 0 0 15px rgba(0,229,191,0.25), 0 0 30px rgba(0,229,191,0.1), 0 0 60px rgba(0,229,191,0.05); text-align:center; padding: 16px; border-radius: 16px; background: #0d1424;">
        <p style="font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:3px; color:#8b9dc3; margin-bottom:6px;">Today Deposit</p>
        <p style="font-size:24px; font-weight:800; color:#fff;" data-testid="text-today-deposit"><?php echo formatINR($todayDeposit); ?></p>
    </div>

    <div class="flex gap-3" style="display:flex; gap:12px;">
        <button onclick="switchTab('upi')" id="tab-upi" class="tab-btn active" style="flex:1; padding:14px; border-radius:12px; font-size:13px; font-weight:700; text-transform:uppercase; letter-spacing:1.5px; cursor:pointer; border:none; background:#16a34a; color:#fff; transition:all 0.3s;" data-testid="tab-instant-upi">
            INSTANT UPI
        </button>
        <button onclick="switchTab('crypto')" id="tab-crypto" class="tab-btn" style="flex:1; padding:14px; border-radius:12px; font-size:13px; font-weight:700; text-transform:uppercase; letter-spacing:1.5px; cursor:pointer; border:1px solid rgba(255,255,255,0.06); background:#0d1424; color:#8b9dc3; transition:all 0.3s;" data-testid="tab-binance">
            BINANCE / USDT
        </button>
    </div>

    <div id="upi-tab">
        <div style="background:#0d1424; border:2px solid #166534; box-shadow:0 0 15px rgba(22,101,52,0.12); border-radius:16px; padding:24px;">
            <div style="text-align:center; padding-bottom:4px; margin-bottom:16px;">
                <div style="width:64px; height:64px; margin:0 auto 12px; position:relative;">
                    <div style="position:absolute; inset:0; border-radius:16px; background:rgba(139,92,246,0.08); border:1.5px solid rgba(139,92,246,0.2);"></div>
                    <div style="position:absolute; inset:8px; border-radius:12px; display:flex; align-items:center; justify-content:center; background:linear-gradient(135deg, #5b21b6, #7c3aed); box-shadow:0 4px 15px rgba(124,58,237,0.4);">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>
                    </div>
                </div>
                <h2 style="font-size:22px; font-weight:800; color:#fff; margin:0 0 6px;">Instant Deposit</h2>
                <p style="font-size:13px; color:#7d8fb3; line-height:1.5;">Add funds instantly with zero manual<br>approval!</p>
            </div>

            <form id="upi-form" action="process_payment.php" method="POST" onsubmit="return validatePayment()">
                <div style="margin-bottom:16px;">
                    <label style="font-size:12px; text-transform:uppercase; letter-spacing:1.5px; font-weight:600; color:#7d8fb3; display:block; margin-bottom:10px;">Amount (₹)</label>
                    <div style="display:flex; align-items:center; border-radius:12px; background:#080d1a; border:1px solid rgba(255,255,255,0.05);">
                        <div style="width:56px; display:flex; align-items:center; justify-content:center; padding:14px 0;">
                            <div style="width:36px; height:36px; border-radius:8px; display:flex; align-items:center; justify-content:center; background:rgba(139,92,246,0.12); border:1px solid rgba(139,92,246,0.2);">
                                <span style="color:#a78bfa; font-weight:700; font-size:15px;">₹</span>
                            </div>
                        </div>
                        <input type="number" name="amount" id="deposit-amount" placeholder="Enter amount" min="1" max="50000" required
                               style="flex:1; padding:14px 4px; background:transparent; border:none; outline:none; font-size:14px; color:#fff; caret-color:#a78bfa;"
                               data-testid="input-deposit-amount" />
                    </div>
                </div>

                <div style="margin-bottom:20px;">
                    <label style="font-size:12px; text-transform:uppercase; letter-spacing:1.5px; font-weight:600; color:#7d8fb3; display:block; margin-bottom:10px;">Mobile Number</label>
                    <div style="display:flex; align-items:center; border-radius:12px; background:#080d1a; border:1px solid rgba(255,255,255,0.05);">
                        <div style="width:56px; display:flex; align-items:center; justify-content:center; padding:14px 0;">
                            <div style="width:36px; height:36px; border-radius:8px; display:flex; align-items:center; justify-content:center; background:rgba(0,221,179,0.08); border:1px solid rgba(0,221,179,0.18);">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#00ddb3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                            </div>
                        </div>
                        <input type="tel" name="mobile" id="deposit-mobile" placeholder="e.g., 9918595291" maxlength="10"
                               style="flex:1; padding:14px 4px; background:transparent; border:none; outline:none; font-size:14px; color:#fff; caret-color:#00ddb3;"
                               data-testid="input-mobile-number" />
                    </div>
                </div>

                <button type="submit" id="pay-btn"
                        style="width:100%; padding:16px; border-radius:16px; font-size:15px; font-weight:700; text-transform:uppercase; letter-spacing:1.5px; color:#fff; border:none; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:10px; background:#1e293b; transition:all 0.3s;"
                        data-testid="button-pay-instantly">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>
                    <span>PAY INSTANTLY</span>
                </button>
            </form>
        </div>
    </div>

    <div id="crypto-tab" style="display:none;">
        <div id="crypto-main" style="background:#0d1424; border:2px solid rgba(245,158,11,0.5); box-shadow:0 0 15px rgba(245,158,11,0.08); border-radius:16px; padding:24px;">
            <h2 style="font-size:22px; font-weight:800; color:#fff; text-align:center; letter-spacing:1px; margin-bottom:20px;">INSTANT USDT PAY</h2>

            <div style="display:flex; justify-content:center; margin-bottom:20px;">
                <div style="border-radius:12px; overflow:hidden; background:#fff; padding:12px; width:220px;">
                    <p style="font-size:11px; text-align:center; color:#6b7280; margin-bottom:8px;">Scan with Binance App to pay</p>
                    <img src="/assets/images/binance-qr.jpg" alt="Binance Pay QR" style="width:100%; object-fit:contain;" data-testid="img-binance-qr" />
                </div>
            </div>

            <div style="display:flex; justify-content:center; margin-bottom:20px;">
                <a href="/assets/images/binance-qr.jpg" download="binance-pay-qr.jpg"
                   style="display:inline-flex; align-items:center; gap:8px; padding:10px 20px; border-radius:8px; font-size:13px; font-weight:600; color:#fff; background:#1a2332; border:1px solid rgba(255,255,255,0.1); text-decoration:none;"
                   data-testid="button-download-qr">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                    DOWNLOAD QR
                </a>
            </div>

            <div style="border-radius:12px; padding:14px 16px; background:#080d1a; border:1.5px solid rgba(245,158,11,0.3); margin-bottom:12px;">
                <p style="font-size:11px; text-transform:uppercase; letter-spacing:2px; font-weight:700; color:#8b9dc3; margin-bottom:4px;">Binance Pay ID</p>
                <div style="display:flex; align-items:center; justify-content:space-between;">
                    <p style="font-size:15px; font-weight:700; color:#fff; font-family:monospace;" data-testid="text-binance-pay-id"><?php echo BINANCE_PAY_ID; ?></p>
                    <button onclick="copyToClipboard('<?php echo BINANCE_PAY_ID; ?>', this)" style="width:32px; height:32px; border-radius:8px; display:flex; align-items:center; justify-content:center; background:rgba(255,255,255,0.05); border:none; cursor:pointer;" data-testid="button-copy-binance-id">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#7d8fb3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                    </button>
                </div>
            </div>

            <div style="border-radius:12px; padding:14px 16px; background:#080d1a; border:1.5px solid rgba(245,158,11,0.3); margin-bottom:20px;">
                <p style="font-size:11px; text-transform:uppercase; letter-spacing:2px; font-weight:700; color:#8b9dc3; margin-bottom:4px;">USDT Address (Tron TRC20)</p>
                <div style="display:flex; align-items:center; justify-content:space-between; gap:8px;">
                    <p style="font-size:13px; font-weight:600; color:#fff; font-family:monospace; word-break:break-all; line-height:1.4;" data-testid="text-usdt-address">Coming Soon</p>
                </div>
            </div>

            <button onclick="showCryptoVerify()" style="width:100%; padding:16px; border-radius:16px; font-size:15px; font-weight:700; text-transform:uppercase; letter-spacing:1.5px; color:#fff; border:none; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:8px; background:#f59e0b; box-shadow:0 4px 20px rgba(245,158,11,0.3);" data-testid="button-i-have-paid">
                I HAVE PAID
            </button>
        </div>

        <div id="crypto-verify" style="display:none; background:#0d1424; border:2px solid rgba(245,158,11,0.5); box-shadow:0 0 15px rgba(245,158,11,0.08); border-radius:16px; padding:24px;">
            <h2 style="font-size:22px; font-weight:800; color:#fff; text-align:center; letter-spacing:1px; margin-bottom:20px;">VERIFY PAYMENT</h2>

            <div style="margin-bottom:16px;">
                <label style="font-size:12px; text-transform:uppercase; letter-spacing:1.5px; font-weight:600; color:#7d8fb3; display:block; margin-bottom:8px;">Panel Name / Username</label>
                <div style="border-radius:12px; padding:14px 16px; background:#080d1a; border:1px solid rgba(255,255,255,0.08);">
                    <p style="font-size:14px; font-weight:700; color:#fff; text-transform:uppercase;" data-testid="text-crypto-username"><?php echo htmlspecialchars($user['username']); ?></p>
                </div>
            </div>

            <div style="margin-bottom:16px;">
                <label style="font-size:12px; text-transform:uppercase; letter-spacing:1.5px; font-weight:600; color:#7d8fb3; display:block; margin-bottom:8px;">Transaction ID (Min 9 Chars)</label>
                <input type="text" id="crypto-txn-id" placeholder="Order ID / Transaction ID"
                       style="width:100%; border-radius:12px; padding:14px 16px; background:#080d1a; border:1px solid rgba(255,255,255,0.08); font-size:14px; color:#fff; outline:none; caret-color:#f59e0b; box-sizing:border-box;"
                       data-testid="input-crypto-txn-id" />
            </div>

            <div style="margin-bottom:16px;">
                <label style="font-size:12px; text-transform:uppercase; letter-spacing:1.5px; font-weight:600; color:#7d8fb3; display:block; margin-bottom:8px;">Amount Paid</label>
                <input type="number" id="crypto-amount" placeholder="Enter Amount Paid"
                       style="width:100%; border-radius:12px; padding:14px 16px; background:#080d1a; border:1px solid rgba(255,255,255,0.08); font-size:14px; color:#fff; outline:none; caret-color:#f59e0b; box-sizing:border-box;"
                       data-testid="input-crypto-amount" />
            </div>

            <div style="margin-bottom:20px;">
                <label style="font-size:12px; text-transform:uppercase; letter-spacing:1.5px; font-weight:600; color:#7d8fb3; display:block; margin-bottom:8px;">Your Contact Number</label>
                <input type="tel" id="crypto-mobile" placeholder="Your Mobile Number" maxlength="10"
                       style="width:100%; border-radius:12px; padding:14px 16px; background:#080d1a; border:1px solid rgba(255,255,255,0.08); font-size:14px; color:#fff; outline:none; caret-color:#f59e0b; box-sizing:border-box;"
                       data-testid="input-crypto-mobile" />
            </div>

            <button onclick="submitCryptoVerification()" style="width:100%; padding:16px; border-radius:16px; font-size:15px; font-weight:700; text-transform:uppercase; letter-spacing:1.5px; color:#fff; border:none; cursor:pointer; display:flex; align-items:center; justify-content:center; gap:8px; background:#f59e0b; box-shadow:0 4px 20px rgba(245,158,11,0.3);" data-testid="button-verify-crypto">
                VERIFY PAYMENT
            </button>

            <div style="text-align:center; margin-top:12px;">
                <button onclick="showCryptoMain()" style="font-size:12px; color:#6b7280; background:none; border:none; cursor:pointer;" data-testid="button-back-crypto">
                    ← Back
                </button>
            </div>
        </div>
    </div>

</div>

<?php if ($activeSession && $activeSession['payment_url']): ?>
<div id="payment-overlay" style="position:fixed; inset:0; background:rgba(0,0,0,0.9); z-index:9999; display:flex; align-items:center; justify-content:center;">
    <div style="max-width:400px; width:90%; border-radius:16px; padding:20px; text-align:center; background:#1a1f35; border:1px solid rgba(0,255,200,0.15);">
        <div style="display:inline-flex; align-items:center; gap:6px; padding:4px 12px; border-radius:999px; font-size:10px; font-weight:700; text-transform:uppercase; letter-spacing:1.5px; margin-bottom:12px; background:rgba(34,197,94,0.1); color:#22c55e; border:1px solid rgba(34,197,94,0.2);">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
            Auto-Verified
        </div>
        <h2 style="font-size:18px; font-weight:700; color:#fff; margin-bottom:4px;" data-testid="text-merchant-name">NEXA PANEL</h2>
        <p style="font-size:24px; font-weight:800; color:#22c55e; margin-bottom:12px;" data-testid="text-payment-amount"><?php echo formatINR($activeSession['amount']); ?></p>

        <div style="display:inline-flex; align-items:center; gap:6px; padding:6px 16px; border-radius:999px; font-size:14px; font-weight:700; margin-bottom:20px; background:rgba(239,68,68,0.1); color:#ef4444; border:1px solid rgba(239,68,68,0.15);">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            <span id="payment-timer" data-testid="text-timer">05:00</span>
        </div>

        <div style="margin-bottom:12px;">
            <div style="display:flex; align-items:center; gap:8px; justify-content:center; font-size:14px; color:#9ca3af;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#22c55e" stroke-width="2" class="spin-animation"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
                <span>Waiting for payment...</span>
            </div>
        </div>

        <p style="font-size:12px; color:#6b7280; margin-bottom:16px;">Complete the payment in the opened window. Your wallet will be credited automatically.</p>

        <a href="<?php echo htmlspecialchars($activeSession['payment_url']); ?>" target="_blank" rel="noopener noreferrer"
           style="display:flex; width:100%; padding:12px; border-radius:8px; font-size:14px; font-weight:700; color:#fff; align-items:center; justify-content:center; gap:8px; background:linear-gradient(135deg, #7c3aed, #6d28d9); text-decoration:none; margin-bottom:8px; box-sizing:border-box;"
           data-testid="link-open-payment">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
            Open Payment Page
        </a>

        <button onclick="cancelPayment(<?php echo $activeSession['id']; ?>)" style="font-size:12px; color:#6b7280; background:none; border:none; cursor:pointer;" data-testid="button-cancel-payment">
            Cancel Payment
        </button>
    </div>
</div>

<style>
@keyframes spin-anim { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
.spin-animation { animation: spin-anim 1s linear infinite; }
</style>

<script>
(function() {
    var sessionId = <?php echo $activeSession['id']; ?>;
    var createdAt = new Date("<?php echo $activeSession['created_at']; ?>").getTime();
    var expiry = createdAt + 300000;

    function updateTimer() {
        var remaining = Math.max(0, Math.floor((expiry - Date.now()) / 1000));
        var m = Math.floor(remaining / 60);
        var s = remaining % 60;
        var el = document.getElementById('payment-timer');
        if (el) el.textContent = String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
        if (remaining <= 0) {
            clearInterval(timerInterval);
            clearInterval(pollInterval);
            document.getElementById('payment-overlay').innerHTML = '<div style="text-align:center;"><h2 style="color:#ef4444;font-size:20px;font-weight:700;">Payment Expired</h2><p style="color:#6b7280;margin:12px 0;">Session expired. Please create a new payment.</p><a href="deposit.php" style="padding:12px 40px;border-radius:8px;background:#22c55e;color:#fff;font-weight:700;text-decoration:none;display:inline-block;">Back to Deposit</a></div>';
        }
    }

    function checkStatus() {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'check_payment.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onload = function() {
            if (xhr.status === 200) {
                try {
                    var data = JSON.parse(xhr.responseText);
                    if (data.success && data.status === 'completed') {
                        clearInterval(timerInterval);
                        clearInterval(pollInterval);
                        document.getElementById('payment-overlay').innerHTML = '<div style="text-align:center;"><div style="width:80px;height:80px;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 20px;background:rgba(34,197,94,0.12);border:2px solid rgba(34,197,94,0.25);"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#22c55e" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg></div><h2 style="color:#fff;font-size:20px;font-weight:700;margin-bottom:8px;">Payment Successful!</h2><p style="color:#6b7280;font-size:14px;margin-bottom:8px;">Your wallet has been credited.</p><p style="font-size:28px;font-weight:800;color:#22c55e;margin-bottom:24px;">₹' + Number(data.amount || <?php echo $activeSession['amount']; ?>).toFixed(2) + '</p><a href="deposit.php" style="padding:12px 40px;border-radius:8px;background:#22c55e;color:#fff;font-weight:700;text-decoration:none;display:inline-block;">Continue</a></div>';
                    } else if (data.status === 'failed' || data.status === 'rejected') {
                        clearInterval(timerInterval);
                        clearInterval(pollInterval);
                        document.getElementById('payment-overlay').innerHTML = '<div style="text-align:center;"><div style="width:80px;height:80px;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 20px;background:rgba(239,68,68,0.12);border:2px solid rgba(239,68,68,0.25);"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg></div><h2 style="color:#fff;font-size:20px;font-weight:700;margin-bottom:8px;">Payment Failed</h2><p style="color:#6b7280;font-size:14px;margin-bottom:24px;">Payment was not completed. Please try again.</p><a href="deposit.php" style="padding:12px 40px;border-radius:8px;background:#22c55e;color:#fff;font-weight:700;text-decoration:none;display:inline-block;">Try Again</a></div>';
                    }
                } catch(e) {}
            }
        };
        xhr.send('session_id=' + sessionId);
    }

    var timerInterval = setInterval(updateTimer, 1000);
    updateTimer();
    setTimeout(checkStatus, 2000);
    var pollInterval = setInterval(checkStatus, 3000);
})();
</script>
<?php endif; ?>

<script>
function switchTab(tab) {
    var upiTab = document.getElementById('upi-tab');
    var cryptoTab = document.getElementById('crypto-tab');
    var tabUpi = document.getElementById('tab-upi');
    var tabCrypto = document.getElementById('tab-crypto');

    if (tab === 'upi') {
        upiTab.style.display = 'block';
        cryptoTab.style.display = 'none';
        tabUpi.style.background = '#16a34a';
        tabUpi.style.color = '#fff';
        tabUpi.style.border = 'none';
        tabCrypto.style.background = '#0d1424';
        tabCrypto.style.color = '#8b9dc3';
        tabCrypto.style.border = '1px solid rgba(255,255,255,0.06)';
    } else {
        upiTab.style.display = 'none';
        cryptoTab.style.display = 'block';
        tabCrypto.style.background = '#7c3aed';
        tabCrypto.style.color = '#fff';
        tabCrypto.style.border = 'none';
        tabUpi.style.background = '#0d1424';
        tabUpi.style.color = '#8b9dc3';
        tabUpi.style.border = '1px solid rgba(255,255,255,0.06)';
        showCryptoMain();
    }
}

function showCryptoMain() {
    document.getElementById('crypto-main').style.display = 'block';
    document.getElementById('crypto-verify').style.display = 'none';
}

function showCryptoVerify() {
    document.getElementById('crypto-main').style.display = 'none';
    document.getElementById('crypto-verify').style.display = 'block';
}

function validatePayment() {
    var amount = document.getElementById('deposit-amount').value;
    if (!amount || Number(amount) <= 0) {
        showToast('Please enter a valid amount.', 'error');
        return false;
    }
    var btn = document.getElementById('pay-btn');
    btn.disabled = true;
    btn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="spin-animation"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> Processing...';
    return true;
}

var amountInput = document.getElementById('deposit-amount');
if (amountInput) {
    amountInput.addEventListener('input', function() {
        var btn = document.getElementById('pay-btn');
        var val = Number(this.value);
        if (val > 0) {
            btn.style.background = '#8b5cf6';
            btn.style.boxShadow = '0 4px 25px rgba(139,92,246,0.4)';
        } else {
            btn.style.background = '#1e293b';
            btn.style.boxShadow = 'none';
        }
    });
}

function submitCryptoVerification() {
    var txnId = document.getElementById('crypto-txn-id').value.trim();
    var amount = document.getElementById('crypto-amount').value.trim();
    var mobile = document.getElementById('crypto-mobile').value.trim();

    if (!txnId || txnId.length < 9) {
        showToast('Transaction ID must be at least 9 characters', 'error');
        return;
    }
    if (!amount || Number(amount) <= 0) {
        showToast('Please enter a valid amount', 'error');
        return;
    }

    var panelName = '<?php echo htmlspecialchars($user['username'], ENT_QUOTES); ?>';
    var msg = 'NEW DEPOSIT REQUEST\n----------------------\nPanel: ' + panelName.toUpperCase() + '\nTXID: ' + txnId + '\nAmount: ' + amount + '\nMobile: ' + (mobile || 'N/A') + '\n----------------------\nPlease verify my payment!';
    var tgUrl = 'https://t.me/<?php echo TELEGRAM_ADMIN; ?>?text=' + encodeURIComponent(msg);
    window.open(tgUrl, '_blank');
    showToast('Your details have been sent to admin on Telegram.', 'success');
}

function cancelPayment(sessionId) {
    document.getElementById('payment-overlay').style.display = 'none';
}

function copyToClipboard(text, btn) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(function() {
            btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#34d399" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>';
            setTimeout(function() {
                btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#7d8fb3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>';
            }, 2000);
        });
    } else {
        var textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        showToast('Copied!', 'success');
    }
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
