<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireLogin();

$userId = $_SESSION['user_id'];
$user = getCurrentUser();
$referralCode = getReferralCode($userId);
$coins = getUserCoins($userId);
$totalReferred = getReferralCount($userId);
$balance = getWalletBalance($userId);

$stmt = $pdo->prepare("SELECT r.*, u.username FROM referrals r JOIN users u ON u.id = r.referred_id WHERE r.referrer_id = ? ORDER BY r.created_at DESC");
$stmt->execute([$userId]);
$referrals = $stmt->fetchAll();

$totalEarned = 0;
foreach ($referrals as $ref) {
    $totalEarned += (int)$ref['reward_amount'];
}

$referralLink = SITE_URL . '/register.php?ref=' . $referralCode;

$pageTitle = 'Referrals';
if (file_exists(__DIR__ . '/../includes/header.php')) {
    include __DIR__ . '/../includes/header.php';
} else {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Referrals - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <style>
        body { background: #050505; color: #fff; font-family: 'Inter', -apple-system, sans-serif; margin: 0; min-height: 100vh; }
        .main-content { max-width: 540px; margin: 0 auto; padding: 24px 16px; }
    </style>
</head>
<body>
<?php } ?>

<div class="main-content">
    <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 20px;">
        <div style="display: inline-flex; align-items: center; gap: 8px; padding: 6px 12px; border-radius: 8px; background: linear-gradient(135deg, rgba(0, 220, 255, 0.08), rgba(0, 220, 255, 0.02)); border: 1px solid rgba(0, 220, 255, 0.2);">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgb(0, 220, 255)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 12 20 22 4 22 4 12"/><rect x="2" y="7" width="20" height="5"/><line x1="12" y1="22" x2="12" y2="7"/><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/></svg>
            <span style="font-size: 12px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.1em; color: rgb(0, 220, 255);">Referral Program</span>
        </div>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 20px;">
        <div style="border-radius: 12px; padding: 16px; background: linear-gradient(135deg, rgba(168, 85, 247, 0.08), rgba(168, 85, 247, 0.02)); border: 1.5px solid rgba(168, 85, 247, 0.25); box-shadow: 0 0 20px rgba(168, 85, 247, 0.08);">
            <div style="display: flex; align-items: center; gap: 12px;">
                <div style="width: 40px; height: 40px; border-radius: 8px; display: flex; align-items: center; justify-content: center; background: rgba(168, 85, 247, 0.15);">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#a78bfa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                </div>
                <div>
                    <p style="font-size: 10px; color: #9ca3af; text-transform: uppercase; letter-spacing: 0.1em; font-weight: 600; margin: 0;">Referred</p>
                    <p style="font-size: 18px; font-weight: 800; color: #fff; margin: 0;" data-testid="text-total-referred"><?= $totalReferred ?></p>
                </div>
            </div>
        </div>
        <div style="border-radius: 12px; padding: 16px; background: linear-gradient(135deg, rgba(245, 158, 11, 0.08), rgba(245, 158, 11, 0.02)); border: 1.5px solid rgba(245, 158, 11, 0.25); box-shadow: 0 0 20px rgba(245, 158, 11, 0.08);">
            <div style="display: flex; align-items: center; gap: 12px;">
                <div style="width: 40px; height: 40px; border-radius: 8px; display: flex; align-items: center; justify-content: center; background: rgba(245, 158, 11, 0.15);">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fbbf24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="8" r="6"/><path d="M18.09 10.37A6 6 0 1 1 10.34 18"/><path d="M7 6h1v4"/><path d="m16.71 13.88.7.71-2.82 2.82"/></svg>
                </div>
                <div>
                    <p style="font-size: 10px; color: #9ca3af; text-transform: uppercase; letter-spacing: 0.1em; font-weight: 600; margin: 0;">Coins</p>
                    <p style="font-size: 18px; font-weight: 800; color: #fbbf24; margin: 0;" data-testid="text-coins-balance"><?= $coins ?></p>
                </div>
            </div>
        </div>
    </div>

    <div id="spin-section" style="border-radius: 12px; padding: 20px; margin-bottom: 20px; background: linear-gradient(180deg, rgba(0, 220, 255, 0.04), rgba(0, 0, 0, 0.3)); border: 2px dashed rgba(0, 220, 255, 0.25);" data-testid="card-lucky-spin">
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 16px;">
            <span style="color: rgb(0, 220, 255); font-weight: 800; font-size: 12px; text-transform: uppercase; letter-spacing: 0.1em;">
                &gt;&gt; User Rewards / Lucky Spin
            </span>
        </div>

        <div style="display: flex; flex-direction: column; align-items: center;">
            <div style="position: relative; width: 280px; height: 300px;">
                <div style="position: absolute; left: 50%; transform: translateX(-50%); z-index: 10; top: -2px;">
                    <div style="width: 0; height: 0; border-left: 12px solid transparent; border-right: 12px solid transparent; border-top: 20px solid #ef4444; filter: drop-shadow(0 2px 4px rgba(239, 68, 68, 0.5));"></div>
                </div>

                <svg id="spin-wheel" width="280" height="280" viewBox="0 0 280 280" style="margin-top: 16px; transition: none;">
                    <circle cx="140" cy="140" r="130" fill="none" stroke="rgba(99, 102, 241, 0.6)" stroke-width="3"/>

                    <path d="M 140 140 L 140 10 A 130 130 0 0 1 270 140 Z" fill="#6366f1" stroke="rgba(99, 102, 241, 0.4)" stroke-width="1.5"/>
                    <text x="196" y="80" fill="#fff" font-size="22" font-weight="bold" text-anchor="middle" dominant-baseline="central" transform="rotate(45, 196, 80)">100</text>
                    <line x1="140" y1="140" x2="140" y2="10" stroke="rgba(99, 102, 241, 0.4)" stroke-width="1.5"/>

                    <path d="M 140 140 L 270 140 A 130 130 0 0 1 140 270 Z" fill="#1e1e3a" stroke="rgba(99, 102, 241, 0.4)" stroke-width="1.5"/>
                    <text x="196" y="200" fill="rgba(255,255,255,0.7)" font-size="22" font-weight="bold" text-anchor="middle" dominant-baseline="central" transform="rotate(135, 196, 200)">5</text>
                    <line x1="140" y1="140" x2="270" y2="140" stroke="rgba(99, 102, 241, 0.4)" stroke-width="1.5"/>

                    <path d="M 140 140 L 140 270 A 130 130 0 0 1 10 140 Z" fill="#6366f1" stroke="rgba(99, 102, 241, 0.4)" stroke-width="1.5"/>
                    <text x="84" y="200" fill="#fff" font-size="22" font-weight="bold" text-anchor="middle" dominant-baseline="central" transform="rotate(225, 84, 200)">20</text>
                    <line x1="140" y1="140" x2="140" y2="270" stroke="rgba(99, 102, 241, 0.4)" stroke-width="1.5"/>

                    <path d="M 140 140 L 10 140 A 130 130 0 0 1 140 10 Z" fill="#1e1e3a" stroke="rgba(99, 102, 241, 0.4)" stroke-width="1.5"/>
                    <text x="84" y="80" fill="rgba(255,255,255,0.7)" font-size="22" font-weight="bold" text-anchor="middle" dominant-baseline="central" transform="rotate(315, 84, 80)">1</text>
                    <line x1="140" y1="140" x2="10" y2="140" stroke="rgba(99, 102, 241, 0.4)" stroke-width="1.5"/>

                    <circle cx="140" cy="140" r="8" fill="rgba(99, 102, 241, 0.8)"/>
                </svg>
            </div>

            <p style="font-size: 13px; color: #9ca3af; margin-top: 8px; text-align: center;">
                COST: <span style="color: #fff; font-weight: 700;">25 coins</span> | WIN UP TO <span style="color: #fff; font-weight: 700;">&#8377;100</span>
            </p>

            <div id="spin-result" style="display: none; margin-top: 8px; padding: 8px 16px; border-radius: 8px; text-align: center; background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.3);">
                <span style="color: #34d399; font-weight: 700; font-size: 18px;" id="spin-result-text"></span>
            </div>

            <button
                id="btn-spin"
                onclick="spinWheel()"
                <?= $coins < SPIN_COST ? 'disabled' : '' ?>
                style="width: 100%; margin-top: 12px; padding: 12px; border-radius: 12px; font-size: 13px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.15em; border: none; cursor: pointer; color: #fff; transition: all 0.3s; background: <?= $coins < SPIN_COST ? 'rgba(128, 128, 128, 0.3)' : 'linear-gradient(135deg, #a855f7, #6366f1, #ec4899)' ?>; box-shadow: <?= $coins < SPIN_COST ? 'none' : '0 0 20px rgba(168, 85, 247, 0.3)' ?>; <?= $coins < SPIN_COST ? 'opacity: 0.5;' : '' ?>"
                data-testid="button-spin"
            >
                SPIN NOW
            </button>
        </div>
    </div>

    <div style="border-radius: 12px; padding: 16px; margin-bottom: 20px; background: linear-gradient(180deg, rgba(0, 220, 255, 0.04), rgba(0, 0, 0, 0.2)); border: 1.5px solid rgba(0, 220, 255, 0.15);">
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 12px;">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgb(0, 220, 255)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
            <p style="font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; color: rgb(0, 220, 255); margin: 0;">Your Referral Link</p>
        </div>
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
            <input
                type="text"
                readonly
                id="referral-link"
                value="<?= htmlspecialchars($referralLink) ?>"
                style="flex: 1; padding: 10px 12px; border-radius: 8px; font-size: 12px; font-family: monospace; color: #d1d5db; outline: none; background: rgba(0, 220, 255, 0.03); border: 1px solid rgba(0, 220, 255, 0.15);"
                data-testid="input-referral-link"
            />
            <button
                onclick="copyReferralLink()"
                id="btn-copy"
                style="width: 40px; height: 40px; border-radius: 8px; display: flex; align-items: center; justify-content: center; border: 1px solid rgba(0, 220, 255, 0.3); background: rgba(0, 220, 255, 0.05); cursor: pointer; transition: all 0.3s;"
                data-testid="button-copy-referral"
            >
                <svg id="icon-copy" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgb(0, 220, 255)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                <svg id="icon-check" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#4ade80" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display:none;"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
            </button>
        </div>
        <p style="font-size: 12px; color: #6b7280; margin: 0;">
            Your code: <span style="font-weight: 700; color: rgb(0, 220, 255);" data-testid="text-referral-code"><?= htmlspecialchars($referralCode) ?></span>
        </p>
    </div>

    <?php if (count($referrals) > 0): ?>
    <div style="border-radius: 12px; padding: 16px; margin-bottom: 20px; background: linear-gradient(180deg, rgba(0, 220, 255, 0.04), rgba(0, 0, 0, 0.2)); border: 1.5px solid rgba(0, 220, 255, 0.15);">
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 12px;">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgb(0, 220, 255)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
            <p style="font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; color: rgb(0, 220, 255); margin: 0;">Referred Users</p>
        </div>
        <div style="display: flex; flex-direction: column; gap: 8px;">
            <?php foreach ($referrals as $i => $ref): ?>
            <div style="display: flex; align-items: center; justify-content: space-between; padding: 8px 12px; border-radius: 8px; background: rgba(0, 220, 255, 0.04); border: 1px solid rgba(0, 220, 255, 0.08);">
                <div style="display: flex; align-items: center; gap: 8px;">
                    <span style="width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 10px; font-weight: 700; background: rgba(168, 85, 247, 0.15); color: #a78bfa;"><?= $i + 1 ?></span>
                    <span style="font-size: 12px; color: #d1d5db;"><?= htmlspecialchars($ref['username']) ?></span>
                </div>
                <span style="font-size: 12px; font-weight: 700; padding: 2px 8px; border-radius: 4px; background: rgba(245, 158, 11, 0.1); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.2);">+<?= (int)$ref['reward_amount'] ?> coins</span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <div style="border-radius: 12px; padding: 16px; margin-bottom: 20px; background: linear-gradient(180deg, rgba(0, 220, 255, 0.03), rgba(0, 0, 0, 0.15)); border: 1px solid rgba(0, 220, 255, 0.1);">
        <p style="font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; color: rgb(0, 220, 255); margin: 0 0 12px 0;">How it works</p>
        <div style="display: flex; flex-direction: column; gap: 8px;">
            <?php
            $steps = [
                'Share your referral link with friends',
                'They register using your referral code',
                'You earn 5 coins for each referral',
                'Use 25 coins to spin the Lucky Wheel',
                'Win up to ₹100 wallet balance per spin!',
            ];
            foreach ($steps as $i => $step):
            ?>
            <div style="display: flex; align-items: center; gap: 8px; padding: 8px 12px; border-radius: 8px; background: rgba(0, 220, 255, 0.04); border: 1px solid rgba(0, 220, 255, 0.08);">
                <span style="width: 20px; height: 20px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 10px; font-weight: 700; flex-shrink: 0; background: rgba(0, 220, 255, 0.12); color: rgb(0, 220, 255);"><?= $i + 1 ?></span>
                <span style="font-size: 14px; color: #9ca3af;"><?= $step ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<script>
var spinCoins = <?= $coins ?>;
var isSpinning = false;
var currentRotation = 0;

function copyReferralLink() {
    var input = document.getElementById('referral-link');
    input.select();
    input.setSelectionRange(0, 99999);
    navigator.clipboard.writeText(input.value).catch(function() {
        document.execCommand('copy');
    });
    document.getElementById('icon-copy').style.display = 'none';
    document.getElementById('icon-check').style.display = 'block';
    setTimeout(function() {
        document.getElementById('icon-copy').style.display = 'block';
        document.getElementById('icon-check').style.display = 'none';
    }, 2000);
}

function spinWheel() {
    if (isSpinning) return;
    if (spinCoins < <?= SPIN_COST ?>) {
        alert('Not enough coins! You need 25 coins to spin. Refer friends to earn coins!');
        return;
    }

    isSpinning = true;
    var btn = document.getElementById('btn-spin');
    btn.textContent = 'SPINNING...';
    btn.disabled = true;
    btn.style.background = 'rgba(128, 128, 128, 0.3)';
    btn.style.boxShadow = 'none';
    document.getElementById('spin-result').style.display = 'none';

    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/user/spin.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                try {
                    var data = JSON.parse(xhr.responseText);
                    if (data.success) {
                        var segments = [
                            { value: 100, index: 0 },
                            { value: 5, index: 1 },
                            { value: 20, index: 2 },
                            { value: 1, index: 3 }
                        ];
                        var prizeIndex = 0;
                        for (var s = 0; s < segments.length; s++) {
                            if (segments[s].value === data.prize) {
                                prizeIndex = segments[s].index;
                                break;
                            }
                        }
                        var segmentAngle = 90;
                        var targetCenter = prizeIndex * segmentAngle + segmentAngle / 2;
                        var spins = 5 + Math.floor(Math.random() * 3);
                        var finalRotation = spins * 360 + (360 - targetCenter);
                        currentRotation += finalRotation;

                        var wheel = document.getElementById('spin-wheel');
                        wheel.style.transition = 'transform 4s cubic-bezier(0.17, 0.67, 0.12, 0.99)';
                        wheel.style.transform = 'rotate(' + currentRotation + 'deg)';

                        setTimeout(function() {
                            isSpinning = false;
                            btn.textContent = 'SPIN NOW';
                            spinCoins = data.newCoins;
                            document.querySelector('[data-testid="text-coins-balance"]').textContent = data.newCoins;

                            document.getElementById('spin-result').style.display = 'block';
                            document.getElementById('spin-result-text').textContent = 'You won \u20B9' + data.prize + '!';

                            if (spinCoins >= <?= SPIN_COST ?>) {
                                btn.disabled = false;
                                btn.style.background = 'linear-gradient(135deg, #a855f7, #6366f1, #ec4899)';
                                btn.style.boxShadow = '0 0 20px rgba(168, 85, 247, 0.3)';
                            } else {
                                btn.style.opacity = '0.5';
                            }

                            wheel.style.transition = 'none';
                        }, 4000);
                    } else {
                        isSpinning = false;
                        btn.textContent = 'SPIN NOW';
                        btn.disabled = false;
                        btn.style.background = 'linear-gradient(135deg, #a855f7, #6366f1, #ec4899)';
                        btn.style.boxShadow = '0 0 20px rgba(168, 85, 247, 0.3)';
                        alert(data.error || 'Failed to spin. Please try again.');
                    }
                } catch (e) {
                    isSpinning = false;
                    btn.textContent = 'SPIN NOW';
                    btn.disabled = false;
                    alert('An error occurred. Please try again.');
                }
            } else {
                isSpinning = false;
                btn.textContent = 'SPIN NOW';
                btn.disabled = false;
                alert('Server error. Please try again.');
            }
        }
    };
    xhr.send('action=spin');
}
</script>

<?php
if (file_exists(__DIR__ . '/../includes/footer.php')) {
    include __DIR__ . '/../includes/footer.php';
} else {
?>
</body>
</html>
<?php } ?>
