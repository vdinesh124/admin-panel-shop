<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'error' => 'Not logged in']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit;
}

$userId = $_SESSION['user_id'];
$coins = getUserCoins($userId);

if ($coins < SPIN_COST) {
    echo json_encode(['success' => false, 'error' => 'Not enough coins. You need ' . SPIN_COST . ' coins to spin.']);
    exit;
}

$prizes = [
    ['value' => 1,   'weight' => 50],
    ['value' => 5,   'weight' => 30],
    ['value' => 20,  'weight' => 15],
    ['value' => 100, 'weight' => 5],
];

$totalWeight = 0;
foreach ($prizes as $p) {
    $totalWeight += $p['weight'];
}

$rand = mt_rand(1, $totalWeight);
$cumulative = 0;
$prize = 1;

foreach ($prizes as $p) {
    $cumulative += $p['weight'];
    if ($rand <= $cumulative) {
        $prize = $p['value'];
        break;
    }
}

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("UPDATE users SET coins = coins - ? WHERE id = ? AND coins >= ?");
    $stmt->execute([SPIN_COST, $userId, SPIN_COST]);

    if ($stmt->rowCount() === 0) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'error' => 'Not enough coins']);
        exit;
    }

    addWalletTransaction($userId, $prize, 'credit', 'Lucky Spin reward - Won ₹' . $prize);

    $pdo->commit();

    $newCoins = getUserCoins($userId);

    echo json_encode([
        'success' => true,
        'prize' => $prize,
        'newCoins' => $newCoins,
    ]);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'error' => 'An error occurred. Please try again.']);
}
