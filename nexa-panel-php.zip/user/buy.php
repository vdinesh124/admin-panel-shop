<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireLogin();

$tierId = (int)($_GET['tier_id'] ?? 0);
if (!$tierId) {
    header("Location: /index.php?error=" . urlencode("Invalid tier selected."));
    exit;
}

$stmt = $pdo->prepare("SELECT pt.*, p.name as product_name, p.id as product_id FROM pricing_tiers pt JOIN products p ON pt.product_id = p.id WHERE pt.id = ?");
$stmt->execute([$tierId]);
$tier = $stmt->fetch();

if (!$tier) {
    header("Location: /index.php?error=" . urlencode("Product tier not found."));
    exit;
}

$userId = $_SESSION['user_id'];
$balance = getWalletBalance($userId);
$price = (float)$tier['price'];

if ($balance < $price) {
    header("Location: /user/deposit.php?error=" . urlencode("Insufficient balance. You need ₹" . number_format($price, 2) . " but have ₹" . number_format($balance, 2) . ". Please deposit funds first."));
    exit;
}

$keyValue = assignLicenseKey($tierId, $userId);
if (!$keyValue) {
    header("Location: /index.php?error=" . urlencode("No keys available for this tier. Please try again later."));
    exit;
}

$pdo->beginTransaction();
try {
    addWalletTransaction($userId, $price, 'debit', 'Purchase: ' . $tier['product_name'] . ' - ' . $tier['label']);

    $stmt = $pdo->prepare("INSERT INTO purchases (user_id, product_id, tier_id, license_key, amount, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt->execute([$userId, $tier['product_id'], $tierId, $keyValue, $price]);

    $pdo->commit();

    header("Location: /user/mykeys.php?bought=1&key=" . urlencode($keyValue));
    exit;
} catch (Exception $e) {
    $pdo->rollBack();
    header("Location: /index.php?error=" . urlencode("Purchase failed. Please try again."));
    exit;
}
