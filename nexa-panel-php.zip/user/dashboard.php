<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireLogin();

$user = getCurrentUser();
$userId = $_SESSION['user_id'];
$balance = getWalletBalance($userId);
$totalPurchases = getUserPurchaseCount($userId);
$totalSpent = getTotalSpent($userId);
$totalReferrals = getReferralCount($userId);

$pageTitle = 'Dashboard';
if (file_exists(__DIR__ . '/../includes/header.php')) {
    include __DIR__ . '/../includes/header.php';
} else {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= SITE_NAME ?> - Dashboard</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<?php } ?>

<div class="main-content">
    <div class="page-container" style="max-width: 900px; margin: 0 auto; padding: 16px;">

        <div class="page-title-bar" style="margin-bottom: 20px;">
            <div style="display: inline-flex; align-items: center; gap: 8px; padding: 6px 12px; border-radius: 6px; background: linear-gradient(135deg, rgba(0, 220, 255, 0.08), rgba(0, 220, 255, 0.02)); border: 1px solid rgba(0, 220, 255, 0.2);">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgba(0, 220, 255, 0.9)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
                <span style="font-size: 13px; font-weight: 800; text-transform: uppercase; letter-spacing: 1.5px; color: rgba(0, 220, 255, 0.9);">Dashboard / Overview</span>
            </div>
        </div>

        <div class="stats-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px;">

            <div class="stat-card" style="border-radius: 12px; padding: 16px; background: linear-gradient(135deg, rgba(16, 185, 129, 0.08), rgba(16, 185, 129, 0.02)); border: 1.5px solid rgba(16, 185, 129, 0.3); box-shadow: 0 0 20px rgba(16, 185, 129, 0.1);">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div style="width: 44px; height: 44px; border-radius: 8px; display: flex; align-items: center; justify-content: center; background: rgba(16, 185, 129, 0.15);">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#34d399" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/><path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/><path d="M18 12a2 2 0 0 0 0 4h4v-4Z"/></svg>
                    </div>
                    <div>
                        <p style="font-size: 10px; color: #9ca3af; text-transform: uppercase; letter-spacing: 2px; font-weight: 600;">Available Balance</p>
                        <p style="font-size: 20px; font-weight: 800; color: #fff; margin-top: 2px;" data-testid="text-stat-balance"><?= formatINR($balance) ?></p>
                    </div>
                </div>
            </div>

            <div class="stat-card" style="border-radius: 12px; padding: 16px; background: linear-gradient(135deg, rgba(59, 130, 246, 0.08), rgba(59, 130, 246, 0.02)); border: 1.5px solid rgba(59, 130, 246, 0.3); box-shadow: 0 0 20px rgba(59, 130, 246, 0.1);">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div style="width: 44px; height: 44px; border-radius: 8px; display: flex; align-items: center; justify-content: center; background: rgba(59, 130, 246, 0.15);">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#60a5fa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
                    </div>
                    <div>
                        <p style="font-size: 10px; color: #9ca3af; text-transform: uppercase; letter-spacing: 2px; font-weight: 600;">Total Purchases</p>
                        <p style="font-size: 20px; font-weight: 800; color: #fff; margin-top: 2px;" data-testid="text-stat-purchases"><?= $totalPurchases ?></p>
                    </div>
                </div>
            </div>

            <div class="stat-card" style="border-radius: 12px; padding: 16px; background: linear-gradient(135deg, rgba(249, 115, 22, 0.08), rgba(249, 115, 22, 0.02)); border: 1.5px solid rgba(249, 115, 22, 0.3); box-shadow: 0 0 20px rgba(249, 115, 22, 0.1);">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div style="width: 44px; height: 44px; border-radius: 8px; display: flex; align-items: center; justify-content: center; background: rgba(249, 115, 22, 0.15);">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fb923c" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="14" x="2" y="5" rx="2"/><line x1="2" x2="22" y1="10" y2="10"/></svg>
                    </div>
                    <div>
                        <p style="font-size: 10px; color: #9ca3af; text-transform: uppercase; letter-spacing: 2px; font-weight: 600;">Total Spent</p>
                        <p style="font-size: 20px; font-weight: 800; color: #fff; margin-top: 2px;" data-testid="text-stat-spent"><?= formatINR($totalSpent) ?></p>
                    </div>
                </div>
            </div>

            <div class="stat-card" style="border-radius: 12px; padding: 16px; background: linear-gradient(135deg, rgba(168, 85, 247, 0.08), rgba(168, 85, 247, 0.02)); border: 1.5px solid rgba(168, 85, 247, 0.3); box-shadow: 0 0 20px rgba(168, 85, 247, 0.1);">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div style="width: 44px; height: 44px; border-radius: 8px; display: flex; align-items: center; justify-content: center; background: rgba(168, 85, 247, 0.15);">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#c084fc" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                    </div>
                    <div>
                        <p style="font-size: 10px; color: #9ca3af; text-transform: uppercase; letter-spacing: 2px; font-weight: 600;">Total Referrals</p>
                        <p style="font-size: 20px; font-weight: 800; color: #fff; margin-top: 2px;" data-testid="text-stat-referrals"><?= $totalReferrals ?></p>
                    </div>
                </div>
            </div>

        </div>

        <div style="border-radius: 12px; padding: 16px; background: linear-gradient(180deg, rgba(0, 220, 255, 0.04), rgba(0, 0, 0, 0.2)); border: 1px solid rgba(0, 220, 255, 0.15);">
            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 12px;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgba(0, 220, 255, 0.9)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/></svg>
                <p style="font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 2px; color: rgba(0, 220, 255, 0.9);">Quick Actions</p>
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                <a href="/user/deposit.php" style="text-decoration: none; display: block;" data-testid="link-quick-deposit">
                    <div class="action-btn-hover" style="padding: 12px; border-radius: 8px; border: 1px solid rgba(16, 185, 129, 0.2); background: rgba(16, 185, 129, 0.04); display: flex; align-items: center; gap: 8px; cursor: pointer;">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#34d399" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/><path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/><path d="M18 12a2 2 0 0 0 0 4h4v-4Z"/></svg>
                        <span style="font-size: 13px; font-weight: 600; color: #d1d5db;">Add Funds</span>
                    </div>
                </a>
                <a href="/index.php" style="text-decoration: none; display: block;" data-testid="link-quick-buy">
                    <div class="action-btn-hover" style="padding: 12px; border-radius: 8px; border: 1px solid rgba(124, 58, 237, 0.2); background: rgba(124, 58, 237, 0.04); display: flex; align-items: center; gap: 8px; cursor: pointer;">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#a78bfa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
                        <span style="font-size: 13px; font-weight: 600; color: #d1d5db;">Browse Stock</span>
                    </div>
                </a>
            </div>
        </div>

    </div>
</div>

<?php
if (file_exists(__DIR__ . '/../includes/footer.php')) {
    include __DIR__ . '/../includes/footer.php';
} else {
?>
<script src="/assets/js/main.js"></script>
</body>
</html>
<?php } ?>
