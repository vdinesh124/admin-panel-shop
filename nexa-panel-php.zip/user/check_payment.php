<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireLogin();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

$sessionId = intval($_POST['session_id'] ?? 0);
$user = getCurrentUser();

if (!$sessionId) {
    echo json_encode(['success' => false, 'message' => 'Missing session ID']);
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM payment_sessions WHERE id = ? AND user_id = ?");
$stmt->execute([$sessionId, $user['id']]);
$session = $stmt->fetch();

if (!$session) {
    echo json_encode(['success' => false, 'message' => 'Session not found']);
    exit;
}

if ($session['status'] === 'completed') {
    echo json_encode(['success' => true, 'status' => 'completed', 'amount' => $session['amount']]);
    exit;
}

if ($session['status'] === 'failed' || $session['status'] === 'rejected') {
    echo json_encode(['success' => false, 'status' => $session['status']]);
    exit;
}

$createdAt = strtotime($session['created_at']);
if (time() - $createdAt > 300) {
    $pdo->prepare("UPDATE payment_sessions SET status = 'failed' WHERE id = ?")->execute([$sessionId]);
    echo json_encode(['success' => false, 'status' => 'expired']);
    exit;
}

$apiKey = PAYINDIA_API_KEY;
$baseUrl = 'https://payment.powercrker.fun/api';

if (!empty($apiKey) && !empty($session['transaction_ref'])) {
    $postData = http_build_query([
        'user_token' => $apiKey,
        'order_id' => $session['transaction_ref'],
    ]);

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $baseUrl . '/check-order-status',
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $postData,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
        CURLOPT_TIMEOUT => 15,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);

    $response = curl_exec($ch);
    curl_close($ch);

    if ($response) {
        $data = json_decode($response, true);

        if (!empty($data['result']) && is_array($data['result'])) {
            $result = $data['result'];
            $txnStatus = strtolower($result['txnStatus'] ?? '');

            if ($txnStatus === 'success' || $txnStatus === 'completed') {
                $pdo->prepare("UPDATE payment_sessions SET status = 'completed' WHERE id = ?")->execute([$sessionId]);

                addWalletTransaction($user['id'], $session['amount'], 'credit', 'UPI deposit via PayIndia');

                echo json_encode(['success' => true, 'status' => 'completed', 'amount' => $session['amount']]);
                exit;
            } elseif ($txnStatus === 'failed' || $txnStatus === 'expired') {
                $pdo->prepare("UPDATE payment_sessions SET status = 'failed' WHERE id = ?")->execute([$sessionId]);

                echo json_encode(['success' => false, 'status' => 'failed']);
                exit;
            }
        }
    }
}

echo json_encode(['success' => false, 'status' => 'pending']);
