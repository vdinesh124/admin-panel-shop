<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireLogin();

$userId = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT * FROM wallet_transactions WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$userId]);
$transactions = $stmt->fetchAll();

$pageTitle = 'History';
if (file_exists(__DIR__ . '/../includes/header.php')) {
    include __DIR__ . '/../includes/header.php';
} else {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= SITE_NAME ?> - Transaction History</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<?php } ?>

<div class="main-content">
    <div class="page-container" style="max-width: 640px; margin: 0 auto; padding: 16px;">

        <div class="page-title-bar" style="margin-bottom: 20px;">
            <div style="display: inline-flex; align-items: center; gap: 8px; padding: 6px 12px; border-radius: 6px; background: linear-gradient(135deg, rgba(0, 220, 255, 0.08), rgba(0, 220, 255, 0.02)); border: 1px solid rgba(0, 220, 255, 0.2);">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgba(0, 220, 255, 0.9)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                <span style="font-size: 13px; font-weight: 800; text-transform: uppercase; letter-spacing: 1.5px; color: rgba(0, 220, 255, 0.9);">Transaction History</span>
            </div>
        </div>

        <?php if (empty($transactions)): ?>
        <div style="text-align: center; padding: 64px 0; color: #6b7280;" data-testid="text-no-transactions">
            No transactions yet.
        </div>
        <?php else: ?>
        <div style="display: flex; flex-direction: column; gap: 8px;">
            <?php foreach ($transactions as $tx):
                $isCredit = $tx['type'] === 'credit';
                $accentColor = $isCredit ? '16, 185, 129' : '239, 68, 68';
                $textColor = $isCredit ? '#34d399' : '#f87171';
                $arrowIcon = $isCredit
                    ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#34d399" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="17" y1="17" x2="7" y2="7"/><polyline points="7 17 7 7 17 7"/></svg>'
                    : '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#f87171" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="7" y1="7" x2="17" y2="17"/><polyline points="17 7 17 17 7 17"/></svg>';
            ?>
            <div class="feature-row-hover" style="border-radius: 12px; padding: 12px; background: rgba(<?= $accentColor ?>, 0.04); border: 1px solid rgba(<?= $accentColor ?>, 0.15);" data-testid="card-transaction-<?= $tx['id'] ?>">
                <div style="display: flex; align-items: center; justify-content: space-between; gap: 12px;">
                    <div style="display: flex; align-items: center; gap: 12px; min-width: 0; flex: 1;">
                        <div style="width: 36px; height: 36px; border-radius: 8px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; background: rgba(<?= $accentColor ?>, 0.12);">
                            <?= $arrowIcon ?>
                        </div>
                        <div style="min-width: 0;">
                            <p style="font-size: 13px; font-weight: 500; color: #e5e7eb; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" data-testid="text-tx-desc-<?= $tx['id'] ?>">
                                <?= htmlspecialchars($tx['description']) ?>
                            </p>
                            <p style="font-size: 10px; color: #6b7280; text-transform: uppercase; letter-spacing: 1px;">
                                <?= date('j M Y, h:i A', strtotime($tx['created_at'])) ?>
                            </p>
                        </div>
                    </div>
                    <div style="flex-shrink: 0;">
                        <span style="font-size: 13px; font-weight: 700; padding: 4px 10px; border-radius: 6px; background: rgba(<?= $accentColor ?>, 0.1); color: <?= $textColor ?>; border: 1px solid rgba(<?= $accentColor ?>, 0.2);" data-testid="text-tx-amount-<?= $tx['id'] ?>">
                            <?= $isCredit ? '+' : '-' ?><?= formatINR(abs($tx['amount'])) ?>
                        </span>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

    </div>
</div>

<?php
if (file_exists(__DIR__ . '/../includes/footer.php')) {
    include __DIR__ . '/../includes/footer.php';
} else {
?>
<script src="/assets/js/main.js"></script>
</body>
</html>
<?php } ?>
