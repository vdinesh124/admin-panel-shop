<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: deposit.php');
    exit;
}

$user = getCurrentUser();
$amount = floatval($_POST['amount'] ?? 0);
$mobile = preg_replace('/[^0-9]/', '', $_POST['mobile'] ?? '9999999999');

if ($amount <= 0 || $amount > 50000) {
    header('Location: deposit.php?error=invalid_amount');
    exit;
}

if (empty($mobile) || strlen($mobile) < 10) {
    $mobile = '9999999999';
}

$orderId = 'NXP' . time() . rand(1000, 9999);

$stmt = $pdo->prepare("INSERT INTO payment_sessions (user_id, amount, transaction_ref, status, created_at) VALUES (?, ?, ?, 'pending', NOW())");
$stmt->execute([$user['id'], $amount, $orderId]);
$sessionId = $pdo->lastInsertId();

$apiKey = PAYINDIA_API_KEY;
$baseUrl = 'https://payment.powercrker.fun/api';
$redirectUrl = SITE_URL . '/user/deposit.php';

if (!empty($apiKey)) {
    $postData = http_build_query([
        'user_token' => $apiKey,
        'order_id' => $orderId,
        'amount' => $amount,
        'customer_mobile' => $mobile,
        'redirect_url' => $redirectUrl,
        'remark1' => 'Wallet deposit for ' . $user['username'],
        'remark2' => 'Session ' . $sessionId,
    ]);

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $baseUrl . '/create-order',
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $postData,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($response && $httpCode === 200) {
        $data = json_decode($response, true);

        if (!empty($data['status']) && !empty($data['result']['payment_url'])) {
            $paymentUrl = $data['result']['payment_url'];
            $apiOrderId = $data['result']['orderId'] ?? $orderId;

            $stmt = $pdo->prepare("UPDATE payment_sessions SET payment_url = ?, transaction_ref = ? WHERE id = ?");
            $stmt->execute([$paymentUrl, $apiOrderId, $sessionId]);

            header('Location: ' . $paymentUrl);
            exit;
        }
    }
}

$stmt = $pdo->prepare("UPDATE payment_sessions SET status = 'failed' WHERE id = ?");
$stmt->execute([$sessionId]);

header('Location: deposit.php?error=payment_failed');
exit;
