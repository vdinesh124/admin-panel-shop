<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireLogin();

$userId = $_SESSION['user_id'];

$stmt = $pdo->prepare("
    SELECT pu.id, pu.license_key, pu.amount, pu.created_at,
           p.name as product_name, pt.label as tier_label
    FROM purchases pu
    LEFT JOIN products p ON pu.product_id = p.id
    LEFT JOIN pricing_tiers pt ON pu.tier_id = pt.id
    WHERE pu.user_id = ?
    ORDER BY pu.created_at DESC
");
$stmt->execute([$userId]);
$purchases = $stmt->fetchAll();

$justBought = $_GET['bought'] ?? '';
$newKey = $_GET['key'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Keys - <?= SITE_NAME ?></title>
    <meta name="description" content="View your purchased license keys at <?= SITE_NAME ?>.">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<?php if (file_exists(__DIR__ . '/../includes/header.php')) include __DIR__ . '/../includes/header.php'; ?>

<div style="max-width:900px;margin:0 auto;padding:20px;">

    <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;">
        <div style="display:inline-flex;align-items:center;gap:8px;padding:6px 12px;border-radius:6px;background:linear-gradient(135deg,rgba(0,220,255,0.08),rgba(0,220,255,0.02));border:1px solid rgba(0,220,255,0.2);">
            <span style="color:#22d3ee;font-size:16px;">&#128273;</span>
            <span style="color:#22d3ee;font-size:13px;font-weight:800;text-transform:uppercase;letter-spacing:1.5px;">My Keys</span>
        </div>
    </div>

    <?php if ($justBought && $newKey): ?>
    <div style="background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.3);color:#34d399;padding:12px 16px;border-radius:8px;margin-bottom:16px;text-align:center;font-weight:700;letter-spacing:1px;font-size:12px;">
        &gt;&gt; KEY COPIED AUTOMATICALLY &lt;&lt;
        <div style="margin-top:8px;font-family:monospace;font-size:11px;color:#5eead4;word-break:break-all;"><?= htmlspecialchars($newKey) ?></div>
        <button onclick="copyToClipboard('<?= htmlspecialchars(addslashes($newKey)) ?>')" style="margin-top:8px;padding:4px 12px;border-radius:4px;font-size:10px;font-weight:700;color:#fff;background:rgba(16,185,129,0.3);border:1px solid rgba(16,185,129,0.5);cursor:pointer;">
            Copy Key
        </button>
    </div>
    <?php endif; ?>

    <?php if (count($purchases) > 0): ?>
    <div style="display:flex;flex-direction:column;gap:12px;">
        <?php foreach ($purchases as $idx => $purchase): ?>
        <div style="border-radius:12px;padding:16px;background:linear-gradient(135deg,rgba(124,58,237,0.06),rgba(0,0,0,0.2));border:1.5px solid rgba(124,58,237,0.2);"
            data-testid="card-purchase-<?= $purchase['id'] ?>">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">
                <div style="display:flex;align-items:center;gap:12px;min-width:0;">
                    <div style="width:40px;height:40px;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0;background:rgba(124,58,237,0.15);">
                        <span style="color:#a78bfa;font-size:16px;">&#128273;</span>
                    </div>
                    <div style="min-width:0;">
                        <p style="font-size:13px;font-weight:600;color:#e5e7eb;margin:0 0 4px 0;">
                            <?= htmlspecialchars($purchase['product_name'] ?? 'Product #' . $purchase['id']) ?>
                            <?php if ($purchase['tier_label']): ?>
                            <span style="color:#6b7280;margin-left:4px;">- <?= htmlspecialchars($purchase['tier_label']) ?></span>
                            <?php endif; ?>
                        </p>
                        <p style="font-size:11px;color:rgba(0,220,255,0.7);font-family:monospace;margin:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:300px;"
                            data-testid="text-license-key-<?= $purchase['id'] ?>" id="key-<?= $purchase['id'] ?>">
                            <?= htmlspecialchars($purchase['license_key']) ?>
                        </p>
                        <p style="font-size:10px;color:#6b7280;margin:4px 0 0 0;">
                            <?= date('M d, Y H:i', strtotime($purchase['created_at'])) ?>
                        </p>
                    </div>
                </div>
                <div style="display:flex;align-items:center;gap:8px;flex-shrink:0;">
                    <span style="font-size:11px;font-weight:700;padding:4px 8px;border-radius:6px;background:rgba(124,58,237,0.1);color:#a78bfa;border:1px solid rgba(124,58,237,0.2);">
                        ₹<?= number_format((float)$purchase['amount'], 2) ?>
                    </span>
                    <button onclick="copyToClipboard('<?= htmlspecialchars(addslashes($purchase['license_key'])) ?>')"
                        style="padding:6px;border-radius:6px;background:none;border:none;cursor:pointer;color:#9ca3af;"
                        title="Copy key" data-testid="button-copy-key-<?= $purchase['id'] ?>">
                        &#128203;
                    </button>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div style="text-align:center;padding:64px 0;border-radius:12px;background:rgba(0,220,255,0.02);border:1px solid rgba(0,220,255,0.08);"
        data-testid="text-no-purchases">
        <span style="font-size:40px;color:#374151;display:block;margin-bottom:12px;">&#128274;</span>
        <p style="color:#6b7280;margin:0;">No purchases yet. Browse the <a href="/index.php" style="color:#22d3ee;text-decoration:none;">marketplace</a> to get started.</p>
    </div>
    <?php endif; ?>

</div>

<?php if (file_exists(__DIR__ . '/../includes/footer.php')) include __DIR__ . '/../includes/footer.php'; ?>

<script>
function copyToClipboard(text) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(function() {
            showCopyToast();
        });
    } else {
        var ta = document.createElement('textarea');
        ta.value = text;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        showCopyToast();
    }
}
function showCopyToast() {
    var toast = document.createElement('div');
    toast.textContent = 'Copied to clipboard!';
    toast.style.cssText = 'position:fixed;bottom:20px;right:20px;padding:10px 20px;border-radius:8px;background:rgba(16,185,129,0.9);color:#fff;font-size:13px;font-weight:600;z-index:9999;';
    document.body.appendChild(toast);
    setTimeout(function() { toast.remove(); }, 2000);
}
</script>
<script src="/assets/js/main.js"></script>
</body>
</html>
