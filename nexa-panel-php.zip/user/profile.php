<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
requireLogin();

$user = getCurrentUser();
$userId = $_SESSION['user_id'];
$balance = getWalletBalance($userId);
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'change_password') {
    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
        $error = 'All password fields are required';
    } elseif ($newPassword !== $confirmPassword) {
        $error = 'New passwords do not match';
    } elseif (strlen($newPassword) < 6) {
        $error = 'New password must be at least 6 characters';
    } elseif (!password_verify($currentPassword, $user['password'])) {
        $error = 'Current password is incorrect';
    } else {
        $hash = password_hash($newPassword, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->execute([$hash, $userId]);
        $success = 'Password updated successfully';
    }
}

$pageTitle = 'Profile';
if (file_exists(__DIR__ . '/../includes/header.php')) {
    include __DIR__ . '/../includes/header.php';
} else {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= SITE_NAME ?> - Profile</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<?php } ?>

<div class="main-content">
    <div class="page-container" style="max-width: 520px; margin: 0 auto; padding: 16px;">

        <div class="page-title-bar" style="margin-bottom: 20px;">
            <div style="display: inline-flex; align-items: center; gap: 8px; padding: 6px 12px; border-radius: 6px; background: linear-gradient(135deg, rgba(0, 220, 255, 0.08), rgba(0, 220, 255, 0.02)); border: 1px solid rgba(0, 220, 255, 0.2);">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgba(0, 220, 255, 0.9)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M12 8v4"/><path d="M12 16h.01"/></svg>
                <span style="font-size: 13px; font-weight: 800; text-transform: uppercase; letter-spacing: 1.5px; color: rgba(0, 220, 255, 0.9);" data-testid="text-page-title">Profile Settings</span>
            </div>
        </div>

        <?php if ($error): ?>
        <div class="toast-error" style="margin-bottom: 16px; padding: 12px 16px; border-radius: 8px; background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); color: #f87171; font-size: 13px; font-weight: 600;">
            <?= htmlspecialchars($error) ?>
        </div>
        <?php endif; ?>

        <?php if ($success): ?>
        <div class="toast-success" style="margin-bottom: 16px; padding: 12px 16px; border-radius: 8px; background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); color: #34d399; font-size: 13px; font-weight: 600;">
            <?= htmlspecialchars($success) ?>
        </div>
        <?php endif; ?>

        <div style="border-radius: 12px; padding: 20px; margin-bottom: 20px; background: linear-gradient(180deg, rgba(15, 20, 40, 0.95) 0%, rgba(10, 15, 30, 0.98) 100%); border: 1.5px solid rgba(0, 220, 255, 0.15); box-shadow: 0 0 20px rgba(0, 220, 255, 0.05);">
            <h2 style="font-size: 13px; font-weight: 800; text-transform: uppercase; letter-spacing: 1.5px; color: #fff; margin-bottom: 16px;" data-testid="text-security-update">&gt;&gt; Security Update</h2>

            <form method="POST" action="">
                <input type="hidden" name="action" value="change_password">

                <div style="margin-bottom: 12px;">
                    <label style="font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 2px; color: rgba(0, 220, 255, 0.6); display: block; margin-bottom: 6px;">Current Password</label>
                    <input type="password" name="current_password" class="input-field" autocomplete="current-password" data-testid="input-current-password" style="width: 100%; padding: 12px 16px; border-radius: 8px; font-size: 13px; color: #fff; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); outline: none; box-sizing: border-box;">
                </div>

                <div style="margin-bottom: 12px;">
                    <label style="font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 2px; color: rgba(0, 220, 255, 0.6); display: block; margin-bottom: 6px;">New Password</label>
                    <input type="password" name="new_password" class="input-field" autocomplete="new-password" data-testid="input-new-password" style="width: 100%; padding: 12px 16px; border-radius: 8px; font-size: 13px; color: #fff; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); outline: none; box-sizing: border-box;">
                </div>

                <div style="margin-bottom: 16px;">
                    <label style="font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 2px; color: rgba(0, 220, 255, 0.6); display: block; margin-bottom: 6px;">Confirm New Password</label>
                    <input type="password" name="confirm_password" class="input-field" autocomplete="new-password" data-testid="input-confirm-new-password" style="width: 100%; padding: 12px 16px; border-radius: 8px; font-size: 13px; color: #fff; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); outline: none; box-sizing: border-box;">
                </div>

                <button type="submit" class="btn-primary" data-testid="button-update-password" style="width: 100%; padding: 12px; border-radius: 8px; font-size: 13px; font-weight: 800; text-transform: uppercase; letter-spacing: 2px; color: #fff; background: linear-gradient(135deg, rgba(0, 220, 255, 0.85), rgba(0, 180, 220, 0.95)); border: none; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 0 20px rgba(0, 220, 255, 0.2);">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                    Update Password
                </button>
            </form>
        </div>

        <div style="border-radius: 12px; padding: 20px; background: linear-gradient(180deg, rgba(15, 20, 40, 0.95) 0%, rgba(10, 15, 30, 0.98) 100%); border: 1.5px solid rgba(0, 220, 255, 0.15); box-shadow: 0 0 20px rgba(0, 220, 255, 0.05);">
            <h2 style="font-size: 13px; font-weight: 800; text-transform: uppercase; letter-spacing: 1.5px; color: #fff; margin-bottom: 16px;" data-testid="text-account-id">&gt;&gt; Account Identification</h2>

            <div style="margin-bottom: 12px;">
                <label style="font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 2px; color: rgba(0, 220, 255, 0.6); display: block; margin-bottom: 6px;">Username</label>
                <div style="width: 100%; padding: 12px 16px; border-radius: 8px; font-size: 13px; color: #fff; font-weight: 600; text-transform: uppercase; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); box-sizing: border-box;" data-testid="text-profile-username">
                    <?= htmlspecialchars($user['username'] ?? 'N/A') ?>
                </div>
            </div>

            <div style="margin-bottom: 16px;">
                <label style="font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 2px; color: rgba(0, 220, 255, 0.6); display: block; margin-bottom: 6px;">Email Address</label>
                <div style="width: 100%; padding: 12px 16px; border-radius: 8px; font-size: 13px; color: #fff; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); box-sizing: border-box;" data-testid="text-profile-email">
                    <?= htmlspecialchars($user['email'] ?: 'Not set') ?>
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 16px;">
                <div>
                    <label style="font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 2px; color: rgba(0, 220, 255, 0.6); display: block; margin-bottom: 6px;">Account Role</label>
                    <div style="padding: 10px 16px; border-radius: 8px; font-size: 13px; font-weight: 700; text-align: center; text-transform: uppercase; background: rgba(124, 58, 237, 0.15); border: 1px solid rgba(124, 58, 237, 0.3); color: rgba(167, 139, 250, 1);" data-testid="text-account-role">
                        User
                    </div>
                </div>
                <div>
                    <label style="font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 2px; color: rgba(0, 220, 255, 0.6); display: block; margin-bottom: 6px;">Current Balance</label>
                    <div style="padding: 10px 16px; border-radius: 8px; font-size: 13px; font-weight: 700; text-align: center; background: rgba(0, 220, 255, 0.08); border: 1px solid rgba(0, 220, 255, 0.2); color: rgb(0, 220, 255);" data-testid="text-current-balance">
                        <?= formatINR($balance) ?>
                    </div>
                </div>
            </div>

            <div style="border-radius: 8px; padding: 12px; background: rgba(0, 220, 255, 0.04); border: 1px solid rgba(0, 220, 255, 0.1);">
                <p style="font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 2px; color: rgba(0, 220, 255, 0.5); margin-bottom: 4px;">Security Note:</p>
                <p style="font-size: 12px; color: #9ca3af;">Account details are verified and locked. Contact admin for manual changes.</p>
            </div>
        </div>

    </div>
</div>

<?php
if (file_exists(__DIR__ . '/../includes/footer.php')) {
    include __DIR__ . '/../includes/footer.php';
} else {
?>
<script src="/assets/js/main.js"></script>
</body>
</html>
<?php } ?>
