<?php
session_start();

define('SITE_NAME', 'NEXA PANEL');
define('SITE_URL', 'https://market.powercrker.fun');

define('DB_HOST', 'localhost');
define('DB_NAME', 'powercrk_mark');
define('DB_USER', 'powercrk_mark');
define('DB_PASS', 'powercrk_mark');

define('ADMIN_USERNAME', 'nexaadmin');
define('ADMIN_PASSWORD', 'Nexa@9787/');

define('PAYINDIA_API_KEY', 'b11af012d3f73a3fe27090a5fd285b6e');
define('UPI_ID', 'paytm.s1t28b2@pty');
define('BINANCE_PAY_ID', '839548203');
define('TELEGRAM_ADMIN', 'NEXAPANELS');
define('TELEGRAM_CHANNEL', 'nexamodoffical');

define('WELCOME_BONUS', 500);
define('REFERRAL_COINS', 5);
define('SPIN_COST', 25);

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    die("Database connection failed. Please run install.php first.");
}
