<?php
if (!isset($pdo)) {
    require_once __DIR__ . '/config.php';
    require_once __DIR__ . '/auth.php';
    require_once __DIR__ . '/functions.php';
}

$currentUser = getCurrentUser();
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
$isAuth = isLoggedIn();
$walletBalance = $isAuth ? getWalletBalance($_SESSION['user_id']) : 0;
$userCoins = $isAuth ? getUserCoins($_SESSION['user_id']) : 0;

$pageTitle = isset($pageTitle) ? $pageTitle . ' - ' . SITE_NAME : SITE_NAME;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars(SITE_NAME); ?> - Premium digital product marketplace for game mods, cheats, and tools.">
    <meta property="og:title" content="<?php echo htmlspecialchars($pageTitle); ?>">
    <meta property="og:description" content="Premium digital product marketplace">
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="app-layout">
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-brand">
                    <div class="brand-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7"/><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><path d="M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4"/><rect width="20" height="5" x="2" y="7"/></svg>
                    </div>
                    <span class="brand-text"><?php echo SITE_NAME; ?></span>
                </div>
            </div>
            <div class="sidebar-content">
                <div class="sidebar-group">
                    <div class="sidebar-group-label"><?php echo $isAuth ? 'NAVIGATION' : 'WELCOME'; ?></div>
                    <nav class="sidebar-menu">
                        <?php if ($isAuth): ?>
                        <a href="/user/dashboard.php" class="sidebar-menu-item <?php echo $currentPage === 'dashboard' ? 'active' : ''; ?>" data-testid="link-sidebar-dashboard">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/></svg>
                            <span>Dashboard</span>
                        </a>
                        <a href="/user/deposit.php" class="sidebar-menu-item <?php echo $currentPage === 'deposit' ? 'active' : ''; ?>" data-testid="link-sidebar-deposit">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2.5"/><path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"/></svg>
                            <span>Deposit</span>
                        </a>
                        <a href="/index.php" class="sidebar-menu-item <?php echo $currentPage === 'index' ? 'active' : ''; ?>" data-testid="link-sidebar-buy-keys">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7"/><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><path d="M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4"/><rect width="20" height="5" x="2" y="7"/></svg>
                            <span>Buy Keys</span>
                        </a>
                        <a href="/user/mykeys.php" class="sidebar-menu-item <?php echo $currentPage === 'mykeys' ? 'active' : ''; ?>" data-testid="link-sidebar-my-keys">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m15.5 7.5 2.3 2.3a1 1 0 0 0 1.4 0l2.1-2.1a1 1 0 0 0 0-1.4L19 4"/><path d="m21 2-9.6 9.6"/><circle cx="7.5" cy="15.5" r="5.5"/></svg>
                            <span>My Keys</span>
                        </a>
                        <a href="/user/history.php" class="sidebar-menu-item <?php echo $currentPage === 'history' ? 'active' : ''; ?>" data-testid="link-sidebar-history">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                            <span>History</span>
                        </a>
                        <a href="/user/referrals.php" class="sidebar-menu-item <?php echo $currentPage === 'referrals' ? 'active' : ''; ?>" data-testid="link-sidebar-referrals">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                            <span>Referrals</span>
                        </a>
                        <a href="/user/profile.php" class="sidebar-menu-item <?php echo $currentPage === 'profile' ? 'active' : ''; ?>" data-testid="link-sidebar-profile">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                            <span>Profile</span>
                        </a>
                        <?php else: ?>
                        <a href="/login.php" class="sidebar-menu-item <?php echo $currentPage === 'login' ? 'active' : ''; ?>" data-testid="link-sidebar-login">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" x2="3" y1="12" y2="12"/></svg>
                            <span>Login</span>
                        </a>
                        <a href="/register.php" class="sidebar-menu-item <?php echo $currentPage === 'register' ? 'active' : ''; ?>" data-testid="link-sidebar-register">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" x2="19" y1="8" y2="14"/><line x1="22" x2="16" y1="11" y2="11"/></svg>
                            <span>Register</span>
                        </a>
                        <a href="/index.php" class="sidebar-menu-item <?php echo $currentPage === 'index' ? 'active' : ''; ?>" data-testid="link-sidebar-buy-keys">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7"/><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><path d="M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4"/><rect width="20" height="5" x="2" y="7"/></svg>
                            <span>Buy Keys</span>
                        </a>
                        <?php endif; ?>
                    </nav>
                </div>
                <div class="sidebar-group">
                    <nav class="sidebar-menu">
                        <a href="https://t.me/<?php echo TELEGRAM_CHANNEL; ?>" target="_blank" rel="noopener noreferrer" class="sidebar-menu-item" data-testid="link-join-telegram">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#29b6f6" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" x2="11" y1="2" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                            <span>Join Telegram</span>
                        </a>
                    </nav>
                </div>
            </div>
            <?php if ($isAuth && $currentUser): ?>
            <div class="sidebar-footer">
                <div class="sidebar-user">
                    <div class="sidebar-avatar" data-testid="img-sidebar-avatar">
                        <?php echo strtoupper(substr($currentUser['username'], 0, 1)); ?>
                    </div>
                    <div class="sidebar-user-info">
                        <span class="sidebar-username" data-testid="text-sidebar-username"><?php echo htmlspecialchars($currentUser['username']); ?></span>
                    </div>
                    <a href="/logout.php" class="sidebar-logout-btn" data-testid="button-logout" title="Logout">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/></svg>
                    </a>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <div class="main-content">
            <div class="rainbow-edge rainbow-edge-left"></div>
            <div class="rainbow-edge rainbow-edge-right"></div>

            <header class="header-bar">
                <div class="header-inner">
                    <button class="hamburger-btn" id="sidebarToggle" data-testid="button-sidebar-toggle" aria-label="Toggle sidebar">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>
                    </button>
                    <div class="header-right">
                        <?php if ($isAuth): ?>
                        <div class="wallet-badge" data-testid="text-wallet-balance">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2.5"/><path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"/></svg>
                            <span><?php echo formatINR($walletBalance); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </header>

            <div class="page-content">
