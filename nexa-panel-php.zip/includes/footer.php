            </div>
        </div>
    </div>

    <a href="https://t.me/<?php echo TELEGRAM_CHANNEL; ?>" target="_blank" rel="noopener noreferrer" class="telegram-float" data-testid="button-telegram">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" x2="11" y1="2" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
    </a>

    <div class="toast-container" id="toastContainer"></div>

    <script src="/assets/js/main.js"></script>
</body>
</html>
