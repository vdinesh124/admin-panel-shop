<?php

function getWalletBalance($userId) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(CASE WHEN type='credit' THEN amount ELSE -amount END), 0) as balance FROM wallet_transactions WHERE user_id = ?");
    $stmt->execute([$userId]);
    return (float)$stmt->fetchColumn();
}

function addWalletTransaction($userId, $amount, $type, $description) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO wallet_transactions (user_id, amount, type, description, created_at) VALUES (?, ?, ?, ?, NOW())");
    $stmt->execute([$userId, $amount, $type, $description]);
}

function getUserCoins($userId) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT coins FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    return (int)$stmt->fetchColumn();
}

function getTodayDeposit($userId) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM wallet_transactions WHERE user_id = ? AND type = 'credit' AND description LIKE '%deposit%' AND DATE(created_at) = CURDATE()");
    $stmt->execute([$userId]);
    return (float)$stmt->fetchColumn();
}

function getUserPurchaseCount($userId) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM purchases WHERE user_id = ?");
    $stmt->execute([$userId]);
    return (int)$stmt->fetchColumn();
}

function getTotalSpent($userId) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM purchases WHERE user_id = ?");
    $stmt->execute([$userId]);
    return (float)$stmt->fetchColumn();
}

function getReferralCount($userId) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM referrals WHERE referrer_id = ?");
    $stmt->execute([$userId]);
    return (int)$stmt->fetchColumn();
}

function getReferralCode($userId) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT referral_code FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    return $stmt->fetchColumn();
}

function getProducts() {
    global $pdo;
    $products = $pdo->query("SELECT * FROM products WHERE status = 'active' ORDER BY id DESC")->fetchAll();
    foreach ($products as &$p) {
        $stmt = $pdo->prepare("SELECT * FROM pricing_tiers WHERE product_id = ? ORDER BY sort_order, price");
        $stmt->execute([$p['id']]);
        $p['tiers'] = $stmt->fetchAll();
        $p['features'] = json_decode($p['features'] ?? '[]', true) ?: [];
    }
    return $products;
}

function getAvailableKeyCount($tierId) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM license_keys WHERE tier_id = ? AND status = 'available'");
    $stmt->execute([$tierId]);
    return (int)$stmt->fetchColumn();
}

function assignLicenseKey($tierId, $userId) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT id, key_value FROM license_keys WHERE tier_id = ? AND status = 'available' LIMIT 1");
    $stmt->execute([$tierId]);
    $key = $stmt->fetch();
    if (!$key) return null;

    $pdo->prepare("UPDATE license_keys SET status = 'sold', sold_to_user_id = ? WHERE id = ?")
        ->execute([$userId, $key['id']]);

    return $key['key_value'];
}

function formatINR($amount) {
    return '₹' . number_format((float)$amount, 2);
}

function timeAgo($datetime) {
    $now = new DateTime();
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    if ($diff->d > 0) return $diff->d . 'd ago';
    if ($diff->h > 0) return $diff->h . 'h ago';
    if ($diff->i > 0) return $diff->i . 'm ago';
    return 'Just now';
}
