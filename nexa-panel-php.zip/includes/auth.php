<?php

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true;
}

function getCurrentUser() {
    if (!isLoggedIn()) return null;
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch();
}

function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: /login.php");
        exit;
    }
}

function requireAdmin() {
    if (!isAdmin()) {
        header("Location: /admin/index.php");
        exit;
    }
}

function registerUser($username, $password, $email = '', $referralCode = '') {
    global $pdo;

    $hash = password_hash($password, PASSWORD_BCRYPT);
    $refCode = strtoupper(substr(md5(uniqid()), 0, 8));

    $stmt = $pdo->prepare("INSERT INTO users (username, password, email, referral_code, coins, created_at) VALUES (?, ?, ?, ?, 0, NOW())");
    $stmt->execute([$username, $hash, $email, $refCode]);
    $userId = $pdo->lastInsertId();

    addWalletTransaction($userId, WELCOME_BONUS, 'credit', 'Welcome bonus');

    if (!empty($referralCode)) {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE referral_code = ?");
        $stmt->execute([$referralCode]);
        $referrer = $stmt->fetch();
        if ($referrer) {
            $pdo->prepare("INSERT INTO referrals (referrer_id, referred_id, reward_amount, created_at) VALUES (?, ?, ?, NOW())")
                ->execute([$referrer['id'], $userId, REFERRAL_COINS]);
            $pdo->prepare("UPDATE users SET coins = coins + ? WHERE id = ?")
                ->execute([REFERRAL_COINS, $referrer['id']]);
        }
    }

    return $userId;
}

function loginUser($username, $password) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        return true;
    }
    return false;
}
