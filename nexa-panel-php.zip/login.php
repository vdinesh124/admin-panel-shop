<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

if (isLoggedIn()) {
    header("Location: /user/dashboard.php");
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $error = 'Please fill in all fields';
    } else {
        if (loginUser($username, $password)) {
            $redirect = $_GET['redirect'] ?? '/user/dashboard.php';
            header("Location: " . $redirect);
            exit;
        } else {
            $error = 'Invalid username or password';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo SITE_NAME; ?></title>
    <meta name="description" content="Login to Nexa Panel - Your premium digital product marketplace">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #000;
            min-height: 100vh;
            overflow: hidden;
        }
        canvas {
            position: absolute;
            inset: 0;
            width: 100%;
            height: 100%;
            z-index: 1;
            touch-action: none;
        }
        .login-wrapper {
            position: relative;
            z-index: 10;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 2rem 1rem;
            pointer-events: none;
        }
        .security-text {
            text-align: center;
            margin-bottom: 1.5rem;
            animation: fadeSlideUp 0.6s ease forwards;
            opacity: 0;
        }
        .security-label {
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.3em;
            color: rgba(0, 220, 255, 0.7);
        }
        .sync-row {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            margin-top: 0.5rem;
        }
        .sync-icon {
            width: 12px;
            height: 12px;
            color: rgba(0, 220, 255, 0.5);
        }
        .sync-text {
            font-size: 10px;
            letter-spacing: 0.1em;
            color: rgba(0, 220, 255, 0.4);
        }
        .login-card-wrapper {
            width: 100%;
            max-width: 380px;
            animation: fadeSlideUp 0.6s 0.15s ease forwards;
            opacity: 0;
            pointer-events: auto;
        }
        .login-card {
            border-radius: 1rem;
            padding: 2rem;
            background: linear-gradient(180deg, rgba(8, 12, 28, 0.96) 0%, rgba(4, 8, 18, 0.98) 100%);
            border: 1.5px solid rgba(0, 220, 255, 0.25);
            box-shadow: 0 0 40px rgba(0, 220, 255, 0.1), 0 0 80px rgba(0, 220, 255, 0.03), inset 0 1px 0 rgba(0, 220, 255, 0.08);
        }
        .logo-section {
            text-align: center;
            padding-top: 0.5rem;
            margin-bottom: 1.5rem;
        }
        .shield-icon {
            width: 72px;
            height: 72px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            background: radial-gradient(circle, rgba(0, 220, 255, 0.15) 0%, rgba(0, 220, 255, 0.05) 70%, transparent 100%);
            border: 2px solid rgba(0, 220, 255, 0.3);
            animation: shieldGlow 3s ease-in-out infinite;
        }
        .shield-icon svg {
            width: 36px;
            height: 36px;
            color: rgb(0, 220, 255);
            filter: drop-shadow(0 0 8px rgba(0, 220, 255, 0.5));
        }
        .brand-title {
            font-size: 22px;
            font-weight: 800;
            letter-spacing: 0.15em;
            text-transform: uppercase;
            color: #fff;
        }
        .brand-title span {
            color: rgb(0, 220, 255);
        }
        .brand-subtitle {
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 0.3em;
            font-weight: 600;
            margin-top: 0.375rem;
            color: rgba(0, 220, 255, 0.5);
        }
        .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
            margin-bottom: 1rem;
        }
        .input-field {
            width: 100%;
            padding: 0.875rem 1rem;
            border-radius: 0.75rem;
            font-size: 13px;
            color: #fff;
            background: rgba(0, 220, 255, 0.03);
            border: 1.5px solid rgba(0, 220, 255, 0.12);
            letter-spacing: 0.05em;
            outline: none;
            transition: all 0.3s;
        }
        .input-field::placeholder {
            color: #6b7280;
        }
        .input-field:focus {
            border-color: rgba(0, 220, 255, 0.4);
            box-shadow: 0 0 15px rgba(0, 220, 255, 0.08);
        }
        .btn-login {
            width: 100%;
            padding: 0.875rem;
            border-radius: 0.75rem;
            font-size: 13px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.2em;
            color: #fff;
            background: linear-gradient(135deg, rgba(0, 220, 255, 0.85), rgba(0, 180, 220, 0.95));
            box-shadow: 0 0 25px rgba(0, 220, 255, 0.25), 0 4px 15px rgba(0, 0, 0, 0.3);
            border: none;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        .btn-login:hover {
            box-shadow: 0 0 35px rgba(0, 220, 255, 0.4), 0 4px 20px rgba(0, 0, 0, 0.4);
        }
        .btn-login:disabled {
            opacity: 0.4;
            cursor: not-allowed;
        }
        .register-link {
            text-align: center;
            font-size: 12px;
            color: #9ca3af;
            margin-top: 1.5rem;
            padding-bottom: 0.25rem;
        }
        .register-link a {
            color: rgb(0, 220, 255);
            font-weight: 600;
            text-decoration: none;
            transition: all 0.2s;
        }
        .register-link a:hover {
            text-decoration: underline;
        }
        .copyright {
            text-align: center;
            font-size: 10px;
            margin-top: 1.25rem;
            letter-spacing: 0.15em;
            text-transform: uppercase;
            color: rgba(100, 110, 130, 0.6);
        }
        .error-msg {
            background: rgba(239, 68, 68, 0.15);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: #fca5a5;
            padding: 0.625rem 1rem;
            border-radius: 0.5rem;
            font-size: 12px;
            text-align: center;
            margin-bottom: 1rem;
        }
        @keyframes fadeSlideUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes shieldGlow {
            0%, 100% { box-shadow: 0 0 20px rgba(0, 220, 255, 0.2); }
            50% { box-shadow: 0 0 40px rgba(0, 220, 255, 0.4); }
        }
        @keyframes syncDots {
            0% { content: ''; }
            25% { content: '.'; }
            50% { content: '..'; }
            75% { content: '...'; }
        }
        .syncing-dots::after {
            content: '...';
            animation: syncDots 1.5s infinite;
        }
    </style>
</head>
<body>
    <canvas id="particleCanvas"></canvas>

    <div class="login-wrapper">
        <div class="security-text">
            <p class="security-label" data-testid="text-security-validation">Security Validation</p>
            <div class="sync-row">
                <svg class="sync-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                <p class="sync-text">Syncing security keys<span class="syncing-dots"></span></p>
            </div>
        </div>

        <div class="login-card-wrapper">
            <div class="login-card">
                <div class="logo-section">
                    <div class="shield-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/></svg>
                    </div>
                    <div>
                        <h1 class="brand-title" data-testid="text-brand">Nexa <span>Panel</span></h1>
                        <p class="brand-subtitle">Authorize Access</p>
                    </div>
                </div>

                <?php if ($error): ?>
                    <div class="error-msg" data-testid="text-error"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="form-group">
                        <input
                            type="text"
                            name="username"
                            placeholder="USER NAME"
                            value="<?php echo htmlspecialchars($username ?? ''); ?>"
                            class="input-field"
                            data-testid="input-login-username"
                            autocomplete="username"
                            required
                        />
                        <input
                            type="password"
                            name="password"
                            placeholder="PASSWORD"
                            class="input-field"
                            data-testid="input-login-password"
                            autocomplete="current-password"
                            required
                        />
                    </div>

                    <button type="submit" class="btn-login" data-testid="button-login">
                        Login Now
                    </button>
                </form>

                <p class="register-link">
                    New User ?
                    <a href="/register.php" data-testid="link-register">Create Account</a>
                </p>
            </div>

            <p class="copyright">&copy; <?php echo date('Y'); ?> Nexa Panel</p>
        </div>
    </div>

    <script>
    (function() {
        const canvas = document.getElementById('particleCanvas');
        const ctx = canvas.getContext('2d');
        let particles = [];
        let maxParticles = 200;
        const mouse = { x: 0, y: 0, active: false };

        function resize() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            initParticles();
        }

        function initParticles() {
            const count = Math.min(Math.floor((canvas.width * canvas.height) / 8000), 150);
            maxParticles = count + 80;
            particles = [];
            for (let i = 0; i < count; i++) {
                particles.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    vx: (Math.random() - 0.5) * 1.2,
                    vy: (Math.random() - 0.5) * 1.2,
                    radius: Math.random() * 5 + 3,
                    opacity: Math.random() * 0.4 + 0.6
                });
            }
        }

        function spawnAtCursor(cx, cy) {
            if (particles.length >= maxParticles) return;
            for (let i = 0; i < 2; i++) {
                const angle = Math.random() * Math.PI * 2;
                const speed = Math.random() * 2 + 0.5;
                particles.push({
                    x: cx + (Math.random() - 0.5) * 20,
                    y: cy + (Math.random() - 0.5) * 20,
                    vx: Math.cos(angle) * speed,
                    vy: Math.sin(angle) * speed,
                    radius: Math.random() * 4 + 2,
                    opacity: Math.random() * 0.3 + 0.7,
                    life: 0,
                    maxLife: 120 + Math.random() * 80
                });
            }
        }

        canvas.addEventListener('mousemove', function(e) {
            mouse.x = e.clientX; mouse.y = e.clientY; mouse.active = true;
            spawnAtCursor(e.clientX, e.clientY);
        });
        canvas.addEventListener('touchmove', function(e) {
            const t = e.touches[0];
            if (t) { mouse.x = t.clientX; mouse.y = t.clientY; mouse.active = true; spawnAtCursor(t.clientX, t.clientY); }
        }, { passive: true });
        canvas.addEventListener('touchstart', function(e) {
            const t = e.touches[0];
            if (t) { mouse.x = t.clientX; mouse.y = t.clientY; mouse.active = true; for (let i = 0; i < 5; i++) spawnAtCursor(t.clientX, t.clientY); }
        }, { passive: true });
        canvas.addEventListener('mouseleave', function() { mouse.active = false; });
        canvas.addEventListener('touchend', function() { mouse.active = false; });

        function animate() {
            const w = canvas.width, h = canvas.height;
            ctx.clearRect(0, 0, w, h);
            const connectionDist = 150;

            for (let i = particles.length - 1; i >= 0; i--) {
                const p = particles[i];
                if (p.life !== undefined && p.maxLife !== undefined) {
                    p.life++;
                    if (p.life >= p.maxLife) { particles.splice(i, 1); continue; }
                    p.opacity = (1 - p.life / p.maxLife) * 0.8;
                }
            }

            for (let i = 0; i < particles.length; i++) {
                const p = particles[i];
                if (mouse.active) {
                    const dx = p.x - mouse.x, dy = p.y - mouse.y;
                    const dist = Math.sqrt(dx * dx + dy * dy);
                    if (dist < 120 && dist > 0) {
                        const force = (120 - dist) / 120 * 0.3;
                        p.vx += (dx / dist) * force;
                        p.vy += (dy / dist) * force;
                    }
                }
                const maxSpeed = 2;
                const speed = Math.sqrt(p.vx * p.vx + p.vy * p.vy);
                if (speed > maxSpeed) { p.vx = (p.vx / speed) * maxSpeed; p.vy = (p.vy / speed) * maxSpeed; }
                p.x += p.vx; p.y += p.vy;
                if (p.x < 0) { p.x = 0; p.vx *= -1; }
                if (p.x > w) { p.x = w; p.vx *= -1; }
                if (p.y < 0) { p.y = 0; p.vy *= -1; }
                if (p.y > h) { p.y = h; p.vy *= -1; }

                for (let j = i + 1; j < particles.length; j++) {
                    const p2 = particles[j];
                    const dx = p.x - p2.x, dy = p.y - p2.y;
                    const dist = Math.sqrt(dx * dx + dy * dy);
                    if (dist < connectionDist) {
                        const alpha = (1 - dist / connectionDist) * 0.5 * Math.min(p.opacity, p2.opacity);
                        ctx.beginPath();
                        ctx.strokeStyle = 'rgba(0, 220, 255, ' + alpha + ')';
                        ctx.lineWidth = 1;
                        ctx.moveTo(p.x, p.y);
                        ctx.lineTo(p2.x, p2.y);
                        ctx.stroke();
                    }
                }

                if (mouse.active) {
                    const dx = p.x - mouse.x, dy = p.y - mouse.y;
                    const dist = Math.sqrt(dx * dx + dy * dy);
                    if (dist < connectionDist) {
                        const alpha = (1 - dist / connectionDist) * 0.6;
                        ctx.beginPath();
                        ctx.strokeStyle = 'rgba(0, 255, 255, ' + alpha + ')';
                        ctx.lineWidth = 1.5;
                        ctx.moveTo(p.x, p.y);
                        ctx.lineTo(mouse.x, mouse.y);
                        ctx.stroke();
                    }
                }
            }

            for (const p of particles) {
                ctx.beginPath();
                const gradient = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.radius * 4);
                gradient.addColorStop(0, 'rgba(0, 255, 255, ' + p.opacity + ')');
                gradient.addColorStop(0.3, 'rgba(0, 220, 255, ' + (p.opacity * 0.6) + ')');
                gradient.addColorStop(0.6, 'rgba(0, 200, 255, ' + (p.opacity * 0.2) + ')');
                gradient.addColorStop(1, 'rgba(0, 220, 255, 0)');
                ctx.fillStyle = gradient;
                ctx.arc(p.x, p.y, p.radius * 4, 0, Math.PI * 2);
                ctx.fill();

                ctx.beginPath();
                ctx.fillStyle = 'rgba(0, 255, 255, ' + p.opacity + ')';
                ctx.shadowColor = 'rgba(0, 255, 255, 0.8)';
                ctx.shadowBlur = 15;
                ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
                ctx.fill();
                ctx.shadowBlur = 0;
            }

            requestAnimationFrame(animate);
        }

        resize();
        window.addEventListener('resize', resize);
        animate();
    })();
    </script>
</body>
</html>