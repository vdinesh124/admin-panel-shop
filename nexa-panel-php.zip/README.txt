========================================
  NEXA PANEL - Digital Product Marketplace
  PHP Version
========================================

REQUIREMENTS:
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Apache/Nginx web server
- mod_rewrite enabled (for Apache)

INSTALLATION:
1. Upload all files to your web server (e.g., public_html/)
2. Create a MySQL database (e.g., "nexa_panel")
3. Edit includes/config.php:
   - Set DB_HOST, DB_NAME, DB_USER, DB_PASS
   - Set ADMIN_USERNAME and ADMIN_PASSWORD
   - Set PAYINDIA_API_KEY (get from payment.powercrker.fun)
   - Set UPI_ID (your UPI ID)
   - Set BINANCE_PAY_ID
   - Set TELEGRAM_ADMIN (your Telegram username)
   - Set TELEGRAM_CHANNEL (your Telegram channel)
4. Open install.php in browser to create database tables
5. Delete install.php after installation (security!)
6. Login at login.php or access admin at admin/index.php

ADMIN PANEL:
- URL: /admin/index.php
- Default credentials: nexaadmin / Nexa@9787/
- Change credentials in includes/config.php

FEATURES:
- User registration with referral system
- Wallet system with ₹500 welcome bonus
- UPI payment via PayIndia gateway (auto-verification)
- Binance/USDT payment with QR code
- Product marketplace with pricing tiers
- License key delivery on purchase
- Transaction history
- Lucky Spin wheel (coins to cash)
- Full admin panel (products, keys, users, payments)
- Dark theme matching adminpanels.shop

FILE STRUCTURE:
├── index.php              - Marketplace (homepage)
├── login.php              - User login
├── register.php           - User registration
├── logout.php             - Logout
├── install.php            - Database installer (delete after use)
├── _product_card.php      - Product card template
├── includes/
│   ├── config.php         - Database & site configuration
│   ├── auth.php           - Authentication functions
│   ├── functions.php      - Helper functions
│   ├── header.php         - Page header + sidebar
│   ├── footer.php         - Page footer
│   ├── admin_header.php   - Admin header + sidebar
│   └── admin_footer.php   - Admin footer
├── user/
│   ├── dashboard.php      - User dashboard
│   ├── deposit.php        - Add funds (UPI/Binance)
│   ├── process_payment.php - PayIndia payment handler
│   ├── check_payment.php  - Payment status checker (AJAX)
│   ├── buy.php            - Purchase handler
│   ├── mykeys.php         - Purchased license keys
│   ├── history.php        - Transaction history
│   ├── referrals.php      - Referrals & Lucky Spin
│   ├── spin.php           - Spin handler (AJAX)
│   └── profile.php        - User profile
├── admin/
│   ├── index.php          - Admin login + dashboard
│   ├── products.php       - Product management
│   ├── keys.php           - License key management
│   ├── users.php          - User management
│   └── payments.php       - Payment approval
└── assets/
    ├── css/style.css      - Main stylesheet
    ├── js/main.js         - Client-side JavaScript
    └── images/            - QR codes, etc.

SUPPORT:
Telegram: @nexamodoffical
