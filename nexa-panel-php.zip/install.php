<?php
$host = 'localhost';
$user = 'powercrk_mark';
$pass = 'powercrk_mark';
$dbname = 'powercrk_mark';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);

    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        email VARCHAR(255) DEFAULT '',
        first_name VARCHAR(100) DEFAULT '',
        last_name VARCHAR(100) DEFAULT '',
        profile_image_url VARCHAR(500) DEFAULT '',
        referral_code VARCHAR(20) UNIQUE,
        coins INT DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS products (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        features JSON,
        image_url VARCHAR(500) DEFAULT '',
        video_url VARCHAR(500) DEFAULT '',
        category VARCHAR(100) DEFAULT '',
        status ENUM('active','inactive') DEFAULT 'active',
        update_url VARCHAR(500) DEFAULT 'https://t.me/ALLHACKPDATE',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS pricing_tiers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        product_id INT NOT NULL,
        label VARCHAR(100) NOT NULL,
        price DECIMAL(10,2) NOT NULL,
        sort_order INT DEFAULT 0,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS license_keys (
        id INT AUTO_INCREMENT PRIMARY KEY,
        tier_id INT NOT NULL,
        product_id INT NOT NULL,
        key_value TEXT NOT NULL,
        status ENUM('available','sold') DEFAULT 'available',
        sold_to_user_id INT DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (tier_id) REFERENCES pricing_tiers(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS purchases (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        product_id INT NOT NULL,
        tier_id INT NOT NULL,
        license_key TEXT,
        amount DECIMAL(10,2) NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (product_id) REFERENCES products(id),
        FOREIGN KEY (tier_id) REFERENCES pricing_tiers(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS wallet_transactions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        amount DECIMAL(10,2) NOT NULL,
        type ENUM('credit','debit') NOT NULL,
        description VARCHAR(500) DEFAULT '',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS payment_sessions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        amount DECIMAL(10,2) NOT NULL,
        transaction_ref VARCHAR(255) DEFAULT '',
        utr VARCHAR(255) DEFAULT '',
        status ENUM('pending','completed','failed','rejected') DEFAULT 'pending',
        payment_url TEXT DEFAULT '',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS referrals (
        id INT AUTO_INCREMENT PRIMARY KEY,
        referrer_id INT NOT NULL,
        referred_id INT NOT NULL,
        reward_amount INT DEFAULT 5,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (referrer_id) REFERENCES users(id),
        FOREIGN KEY (referred_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    echo '<!DOCTYPE html><html><head><title>Install - NEXA PANEL</title>
    <style>body{background:#050505;color:#fff;font-family:Inter,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}
    .box{background:#0d1424;border:2px solid #00e5bf;border-radius:16px;padding:40px;text-align:center;max-width:500px;box-shadow:0 0 30px rgba(0,229,191,0.15)}
    h1{color:#00e5bf;margin-bottom:10px}p{color:#8b9dc3}a{color:#8b5cf6;text-decoration:none;font-weight:700}</style></head>
    <body><div class="box"><h1>&#10004; Installation Complete!</h1><p>All 8 database tables created successfully.</p><p style="margin-top:20px"><a href="/login.php">Go to Login &rarr;</a></p><p style="margin-top:10px;color:#ef4444;font-size:12px">DELETE this file after installation!</p></div></body></html>';

} catch (PDOException $e) {
    echo '<!DOCTYPE html><html><head><title>Install Error</title>
    <style>body{background:#050505;color:#fff;font-family:Inter,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}
    .box{background:#0d1424;border:2px solid #ef4444;border-radius:16px;padding:40px;text-align:center;max-width:500px}
    h1{color:#ef4444;margin-bottom:10px}p{color:#8b9dc3}code{color:#f59e0b;background:#1e293b;padding:2px 8px;border-radius:4px;font-size:13px}</style></head>
    <body><div class="box"><h1>&#10008; Installation Error</h1><p>' . htmlspecialchars($e->getMessage()) . '</p>
    <p style="margin-top:15px">Check your database credentials in <code>includes/config.php</code></p></div></body></html>';
}
