<?php
$features = $product['features'] ?? [];
$tiers = $product['tiers'] ?? [];
$videoUrl = $product['video_url'] ?? '';
$updateUrl = $product['update_url'] ?? '';
$feedbackUrl = $product['feedback_url'] ?? '';
$youtubeUrl = $product['youtube_url'] ?? '';
$productId = $product['id'];
?>
<div class="product-card" data-testid="card-product-<?= $productId ?>" style="border-radius:12px;overflow:hidden;display:flex;flex-direction:column;border:2px solid rgba(0,220,255,0.4);background:linear-gradient(180deg,#0d0d1a 0%,#1a1a2e 100%);">

    <div style="position:relative;background:#000;overflow:hidden;min-height:180px;">
        <?php if ($videoUrl): ?>
        <video
            class="product-video"
            src="<?= htmlspecialchars($videoUrl) ?>#t=0.1"
            style="width:100%;aspect-ratio:16/9;object-fit:cover;background:#000;display:block;"
            loop playsinline preload="metadata"
            data-testid="video-product-<?= $productId ?>"
        ></video>
        <div style="position:absolute;inset:0;background:linear-gradient(to top,rgba(0,0,0,0.6) 0%,transparent 50%);pointer-events:none;"></div>
        <button onclick="toggleProductVideo(this)" class="video-play-btn" data-testid="button-playpause-<?= $productId ?>"
            style="position:absolute;inset:0;z-index:10;display:flex;align-items:center;justify-content:center;background:none;border:none;cursor:pointer;">
            <div style="width:56px;height:56px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,0.5);border:3px solid rgba(0,220,255,0.8);">
                <span class="play-icon" style="font-size:24px;color:#fff;margin-left:3px;">&#9654;</span>
                <span class="pause-icon" style="font-size:24px;color:#fff;display:none;">&#10074;&#10074;</span>
            </div>
        </button>
        <?php else: ?>
        <div style="width:100%;aspect-ratio:16/9;display:flex;align-items:center;justify-content:center;background:radial-gradient(ellipse at center,rgba(0,220,255,0.05) 0%,rgba(0,0,0,0.95) 70%);">
            <span style="font-size:40px;color:rgba(0,220,255,0.3);">&#9654;</span>
        </div>
        <?php endif; ?>

        <?php if ($youtubeUrl && $youtubeUrl !== '#'): ?>
        <a href="<?= htmlspecialchars($youtubeUrl) ?>" target="_blank" rel="noopener noreferrer"
            style="position:absolute;top:8px;left:8px;z-index:20;display:inline-flex;align-items:center;gap:4px;padding:4px 8px;border-radius:4px;font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:#fff;background:linear-gradient(135deg,#dc2626,#b91c1c);text-decoration:none;box-shadow:0 2px 8px rgba(220,38,38,0.4);"
            data-testid="link-youtube-<?= $productId ?>">
            &#9654; Watch on YouTube
        </a>
        <?php endif; ?>
    </div>

    <div style="flex:1;display:flex;flex-direction:column;background:linear-gradient(180deg,#1a1a2e 0%,#12122a 100%);">
        <div style="padding:12px 12px 8px;">
            <h5 style="font-size:13px;font-weight:800;text-transform:uppercase;letter-spacing:1.5px;text-align:center;color:#fff;margin:0 0 12px 0;"
                data-testid="text-product-name-<?= $productId ?>">
                <?= htmlspecialchars($product['name']) ?>
            </h5>

            <div class="features-list" style="display:flex;flex-direction:column;gap:6px;">
                <?php foreach (array_slice($features, 0, 5) as $idx => $feature): ?>
                <div style="display:flex;align-items:center;gap:8px;padding:6px 12px;border-radius:6px;font-size:12px;background:rgba(0,220,255,0.04);border:1px solid rgba(0,220,255,0.1);">
                    <span style="color:#22d3ee;font-size:11px;">&#9889;</span>
                    <span style="color:#d1d5db;font-weight:500;"><?= htmlspecialchars(ltrim($feature, '- ')) ?></span>
                </div>
                <?php endforeach; ?>
                <?php if (count($features) > 5): ?>
                <div style="text-align:center;color:#6b7280;font-size:11px;padding:4px 0;">
                    +<?= count($features) - 5 ?> more features
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div style="padding:0 12px 12px;margin-top:auto;">
            <div style="display:flex;gap:8px;margin-bottom:8px;">
                <?php if ($updateUrl && $updateUrl !== '#'): ?>
                <a href="<?= htmlspecialchars($updateUrl) ?>" target="_blank" rel="noopener noreferrer" style="flex:1;text-decoration:none;"
                    data-testid="link-update-<?= $productId ?>">
                    <div style="display:flex;align-items:center;justify-content:center;gap:6px;padding:8px;border-radius:6px;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:#d1d5db;border:1px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.02);cursor:pointer;text-align:center;">
                        Check Update File
                    </div>
                </a>
                <?php endif; ?>
                <?php if ($feedbackUrl && $feedbackUrl !== '#'): ?>
                <a href="<?= htmlspecialchars($feedbackUrl) ?>" target="_blank" rel="noopener noreferrer" style="flex:1;text-decoration:none;"
                    data-testid="link-feedback-<?= $productId ?>">
                    <div style="display:flex;align-items:center;justify-content:center;gap:6px;padding:8px;border-radius:6px;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:#d1d5db;border:1px solid rgba(255,255,255,0.12);background:rgba(255,255,255,0.02);cursor:pointer;text-align:center;">
                        Check Video / Feedback
                    </div>
                </a>
                <?php endif; ?>
            </div>

            <div class="tier-section">
                <button onclick="toggleTiers(this)" class="purchase-btn" data-testid="button-purchase-<?= $productId ?>"
                    style="width:100%;padding:10px;border-radius:6px;font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:2px;color:#fff;background:linear-gradient(135deg,#7c3aed 0%,#c026d3 50%,#ec4899 100%);border:none;cursor:pointer;">
                    Purchase Key
                </button>
                <div class="tiers-dropdown" style="display:none;margin-top:8px;">
                    <?php foreach ($tiers as $tIdx => $tier): ?>
                    <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;padding:8px 12px;border-radius:6px;background:rgba(124,58,237,0.08);border:1px solid rgba(124,58,237,0.2);margin-bottom:6px;"
                        data-testid="row-tier-<?= $tier['id'] ?>">
                        <span style="font-size:12px;font-weight:600;color:#d1d5db;" data-testid="text-tier-label-<?= $tier['id'] ?>"><?= htmlspecialchars($tier['label']) ?></span>
                        <div style="display:flex;align-items:center;gap:8px;">
                            <span style="font-size:12px;font-weight:700;color:#fff;" data-testid="text-tier-price-<?= $tier['id'] ?>">₹<?= number_format((float)$tier['price'], 0) ?></span>
                            <?php if (isLoggedIn()): ?>
                            <a href="/user/buy.php?tier_id=<?= $tier['id'] ?>" onclick="return confirm('Buy <?= htmlspecialchars(addslashes($tier['label'])) ?> for ₹<?= number_format((float)$tier['price'], 0) ?>?')"
                                style="display:inline-block;padding:4px 12px;border-radius:4px;font-size:10px;font-weight:700;text-transform:uppercase;color:#fff;background:linear-gradient(135deg,#7c3aed,#c026d3);text-decoration:none;border:none;"
                                data-testid="button-buy-tier-<?= $tier['id'] ?>">
                                Buy
                            </a>
                            <?php else: ?>
                            <a href="/login.php?redirect=/"
                                style="display:inline-block;padding:4px 12px;border-radius:4px;font-size:10px;font-weight:700;text-transform:uppercase;color:#fff;background:linear-gradient(135deg,#7c3aed,#c026d3);text-decoration:none;border:none;"
                                data-testid="button-buy-tier-<?= $tier['id'] ?>">
                                Buy
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function toggleTiers(btn) {
    var dropdown = btn.nextElementSibling;
    dropdown.style.display = dropdown.style.display === 'none' ? 'block' : 'none';
}
function toggleProductVideo(btn) {
    var card = btn.closest('.product-card');
    var video = card.querySelector('.product-video');
    if (!video) return;
    var playIcon = btn.querySelector('.play-icon');
    var pauseIcon = btn.querySelector('.pause-icon');
    if (video.paused) {
        video.muted = false;
        video.play();
        if (playIcon) playIcon.style.display = 'none';
        if (pauseIcon) pauseIcon.style.display = 'inline';
    } else {
        video.pause();
        video.muted = true;
        if (playIcon) playIcon.style.display = 'inline';
        if (pauseIcon) pauseIcon.style.display = 'none';
    }
}
</script>
