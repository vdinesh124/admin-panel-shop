<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

$products = getProducts();
$balance = isLoggedIn() ? getWalletBalance($_SESSION['user_id']) : 0;

$mobileProducts = [];
$pcProducts = [];
foreach ($products as $p) {
    if (($p['category'] ?? '') === 'pc') {
        $pcProducts[] = $p;
    } else {
        $mobileProducts[] = $p;
    }
}

$buySuccess = $_GET['bought'] ?? '';
$buyError = $_GET['error'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marketplace - <?= SITE_NAME ?></title>
    <meta name="description" content="Browse and purchase premium digital products, license keys, and game panels at <?= SITE_NAME ?>.">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
<?php if (file_exists(__DIR__ . '/includes/header.php')) include __DIR__ . '/includes/header.php'; ?>

<div class="marketplace-container" style="max-width:1100px;margin:0 auto;padding:20px;">

    <?php if ($buySuccess): ?>
    <div class="alert alert-success" style="background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.3);color:#34d399;padding:12px 16px;border-radius:8px;margin-bottom:16px;text-align:center;font-weight:700;letter-spacing:1px;font-size:12px;">
        &gt;&gt; KEY COPIED AUTOMATICALLY &lt;&lt; — Check My Keys page
    </div>
    <?php endif; ?>

    <?php if ($buyError): ?>
    <div class="alert alert-error" style="background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);color:#f87171;padding:12px 16px;border-radius:8px;margin-bottom:16px;text-align:center;font-weight:600;font-size:13px;">
        <?= htmlspecialchars($buyError) ?>
    </div>
    <?php endif; ?>

    <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">
        <div style="display:inline-flex;align-items:center;gap:8px;padding:6px 12px;border-radius:6px;background:linear-gradient(135deg,rgba(0,220,255,0.08),rgba(0,220,255,0.02));border:1px solid rgba(0,220,255,0.2);">
            <span style="color:#22d3ee;font-size:13px;font-weight:800;text-transform:uppercase;letter-spacing:1.5px;">Marketplace / User Stock</span>
        </div>
        <div style="display:inline-flex;align-items:center;gap:6px;padding:4px 8px;border-radius:4px;background:rgba(16,185,129,0.08);border:1px solid rgba(16,185,129,0.2);color:#34d399;font-size:10px;font-weight:600;">
            LIVE
        </div>
    </div>

    <?php if (isLoggedIn()): ?>
    <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 16px;border-radius:8px;background:linear-gradient(135deg,rgba(0,220,255,0.06),rgba(0,0,0,0.3));border:1px solid rgba(0,220,255,0.2);margin-bottom:20px;">
        <p style="font-size:13px;font-weight:600;color:#9ca3af;text-transform:uppercase;letter-spacing:1px;margin:0;">Available Balance:</p>
        <h4 style="font-size:20px;font-weight:800;color:#fff;margin:0;" data-testid="text-balance-display"><?= formatINR($balance) ?></h4>
    </div>
    <?php endif; ?>

    <?php if (count($mobileProducts) > 0): ?>
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">
        <div style="display:inline-flex;align-items:center;gap:8px;padding:6px 12px;border-radius:6px;background:linear-gradient(135deg,rgba(0,220,255,0.08),rgba(0,220,255,0.02));border:1px solid rgba(0,220,255,0.25);">
            <span style="color:#22d3ee;font-size:13px;font-weight:800;text-transform:uppercase;letter-spacing:1.5px;">Mobile Panels</span>
        </div>
    </div>
    <div class="products-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:20px;margin-bottom:30px;">
        <?php foreach ($mobileProducts as $product): ?>
            <?php include __DIR__ . '/_product_card.php'; ?>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if (count($pcProducts) > 0): ?>
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">
        <div style="display:inline-flex;align-items:center;gap:8px;padding:6px 12px;border-radius:6px;background:linear-gradient(135deg,rgba(168,85,247,0.1),rgba(168,85,247,0.02));border:1px solid rgba(168,85,247,0.3);">
            <span style="color:#c084fc;font-size:13px;font-weight:800;text-transform:uppercase;letter-spacing:1.5px;">PC Panels</span>
        </div>
    </div>
    <div class="products-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:20px;margin-bottom:30px;">
        <?php foreach ($pcProducts as $product): ?>
            <?php include __DIR__ . '/_product_card.php'; ?>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if (empty($products)): ?>
    <div style="text-align:center;padding:64px 0;color:#6b7280;">
        No products available at the moment.
    </div>
    <?php endif; ?>

</div>

<?php if (file_exists(__DIR__ . '/includes/footer.php')) include __DIR__ . '/includes/footer.php'; ?>
<script src="/assets/js/main.js"></script>
</body>
</html>
